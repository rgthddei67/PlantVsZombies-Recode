#pragma once
#ifndef _RESOURCEMANAGER_H
#define _RESOURCEMANAGER_H
#include "./Reanimation/Reanimation.h"
#include "./Reanimation/AnimationTypes.h"
#include "ResourcesXMLConfigReader.h"
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_mixer.h>
#include <string>
#include <unordered_map>
#include <memory>
#include <iostream>

class Animator;

class ResourceManager
{
private:
    std::unordered_map<std::string, std::shared_ptr<Reanimation>> mReanimations;  // �Ѽ��صĶ���
    std::unordered_map<std::string, SDL_Texture*> textures;
    std::unordered_map<std::string, std::unordered_map<int, TTF_Font*>> fonts;
    std::unordered_map<std::string, Mix_Chunk*> sounds;
    std::unordered_map<std::string, Mix_Music*> music;

    SDL_Renderer* renderer;
    ResourcesXMLConfigReader configReader;

    static ResourceManager* instance;
    ResourceManager() : renderer(nullptr) 
    {
    }

    // ��Surface��������������ͨ������
    SDL_Texture* CreateTextureFromSurface(SDL_Surface* surface);
    // ���طָ���ͼ
    bool LoadTiledTexture(const TiledImageInfo& info, const std::string& prefix);

public:
    // ��������
    static ResourceManager& GetInstance();
    static void ReleaseInstance();

    bool Initialize(SDL_Renderer* renderer, const std::string& configPath = "./resources/resources.xml");

    // ͳһ���ط���
    bool LoadAllGameImages();
    bool LoadAllParticleTextures();
    bool LoadAllFonts();
    bool LoadAllSounds();
    bool LoadAllMusic();
    bool LoadAllReanimations();

    // ��ȡ��Դ��
    const std::vector<TiledImageInfo>& GetGameImageInfos() const { return configReader.GetGameImageInfos(); }
    const std::vector<TiledImageInfo>& GetParticleTextureInfos() const { return configReader.GetParticleTextureInfos(); }
    const std::vector<std::string>& GetSoundPaths() const { return configReader.GetSoundPaths(); }
    const std::vector<std::string>& GetMusicPaths() const { return configReader.GetMusicPaths(); }
    const std::unordered_map<std::string, std::string>& GetAnimationPaths() const { return configReader.GetReanimationPaths(); }

    // ��������
    SDL_Texture* LoadTexture(const std::string& path, const std::string& key = "");
    SDL_Texture* GetTexture(const std::string& key);
    void UnloadTexture(const std::string& key);

    std::shared_ptr<Reanimation> LoadReanimation(const std::string& key, const std::string& path);
    std::shared_ptr<Reanimation> GetReanimation(const std::string& key);
    std::string AnimationTypeToString(AnimationType type);
    void UnloadReanimation(const std::string& key);

    // �������
    bool LoadFont(const std::string& path, const std::string& key = "");
    TTF_Font* GetFont(const std::string& key, int size);
    void UnloadFont(const std::string& key);
    void UnloadFontSize(const std::string& key, int size);
    void CleanupUnusedFontSizes();

    // ��ȡ������Ϣ
    std::vector<int> GetLoadedFontSizes(const std::string& key) const;
    int GetLoadedFontCount() const;

    // ��Ч����
    Mix_Chunk* LoadSound(const std::string& path, const std::string& key = "");
    Mix_Chunk* GetSound(const std::string& key);
    void UnloadSound(const std::string& key);

    // ���ֹ���
    Mix_Music* LoadMusic(const std::string& path, const std::string& key = "");
    Mix_Music* GetMusic(const std::string& key);
    void UnloadMusic(const std::string& key);

    // ��������
    void LoadTexturePack(const std::vector<std::pair<std::string, std::string>>& texturePaths);
    void UnloadAll();

    bool HasTexture(const std::string& key) const;
    bool HasFont(const std::string& key) const;
    bool HasSound(const std::string& key) const;
    bool HasMusic(const std::string& key) const;
    bool HasReanimation(const std::string& key) const;

    // ����·�����ɱ�׼����key
    std::string GenerateTextureKey(const std::string& path);
    // ��д��
    std::string GenerateStandardKey(const std::string& path, const std::string& prefix);

    ResourceManager(const ResourceManager&) = delete;
    ResourceManager& operator=(const ResourceManager&) = delete;
};

#endif