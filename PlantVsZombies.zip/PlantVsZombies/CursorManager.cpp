#include "CursorManager.h"
#include <iostream>

CursorManager::CursorManager() {
    // ��ʼ��ϵͳ���ӳ��
    mSystemCursors[CursorType::ARROW] = nullptr;
    mSystemCursors[CursorType::HAND] = nullptr;
    mSystemCursors[CursorType::IBEAM] = nullptr;
    mSystemCursors[CursorType::CROSSHAIR] = nullptr;
    mSystemCursors[CursorType::WAIT] = nullptr;
    mSystemCursors[CursorType::SIZE_ALL] = nullptr;
    mSystemCursors[CursorType::NO] = nullptr;
}

CursorManager::~CursorManager() {
    Cleanup();
}

CursorManager& CursorManager::GetInstance() {
    static CursorManager instance;
    return instance;
}

bool CursorManager::Initialize() {
    if (mIsInitialized) return true;

    // ��ʼ��ϵͳ���
    InitializeSystemCursors();

    mIsInitialized = true;
    SetDefaultCursor();

#ifdef _DEBUG
    std::cout << "CursorManager initialized successfully." << std::endl;
#endif

    return true;
}

void CursorManager::InitializeSystemCursors() {
    mSystemCursors[CursorType::ARROW] = SDL_CreateSystemCursor(SDL_SYSTEM_CURSOR_ARROW);
    mSystemCursors[CursorType::HAND] = SDL_CreateSystemCursor(SDL_SYSTEM_CURSOR_HAND);
    mSystemCursors[CursorType::IBEAM] = SDL_CreateSystemCursor(SDL_SYSTEM_CURSOR_IBEAM);
    mSystemCursors[CursorType::CROSSHAIR] = SDL_CreateSystemCursor(SDL_SYSTEM_CURSOR_CROSSHAIR);
    mSystemCursors[CursorType::WAIT] = SDL_CreateSystemCursor(SDL_SYSTEM_CURSOR_WAIT);
    mSystemCursors[CursorType::SIZE_ALL] = SDL_CreateSystemCursor(SDL_SYSTEM_CURSOR_SIZEALL);
    mSystemCursors[CursorType::NO] = SDL_CreateSystemCursor(SDL_SYSTEM_CURSOR_NO);

    // ����Ƿ񶼴����ɹ�
    for (auto& [type, cursor] : mSystemCursors) {
        if (!cursor) {
            std::cerr << "Failed to create system cursor for type: " << static_cast<int>(type) << std::endl;
        }
    }
}

void CursorManager::Cleanup() {
    if (!mIsInitialized) return;

    CleanupAllCursors();
    mIsInitialized = false;
    mCurrentCursor = nullptr;
}

void CursorManager::CleanupAllCursors() {
    // ����ϵͳ���
    for (auto& [type, cursor] : mSystemCursors) {
        if (cursor) {
            SDL_FreeCursor(cursor);
            cursor = nullptr;
        }
    }

    // �����Զ�����
    for (auto& [name, cursor] : mCustomCursors) {
        if (cursor) {
            SDL_FreeCursor(cursor);
        }
    }
    mCustomCursors.clear();
}

bool CursorManager::SetCursor(CursorType type) {
    if (!mIsInitialized) return false;

    SDL_Cursor* newCursor = GetSystemCursor(type);
    if (!newCursor) {
        std::cerr << "Cursor type not available: " << static_cast<int>(type) << std::endl;
        return false;
    }

    if (newCursor != mCurrentCursor) {
        SDL_SetCursor(newCursor);
        mCurrentCursor = newCursor;
        return true;
    }

    return false;
}

bool CursorManager::SetCustomCursor(const std::string& cursorName) {
    if (!mIsInitialized) return false;

    auto it = mCustomCursors.find(cursorName);
    if (it == mCustomCursors.end()) {
        std::cerr << "Custom cursor not found: " << cursorName << std::endl;
        return false;
    }

    SDL_Cursor* newCursor = it->second;
    if (newCursor && newCursor != mCurrentCursor) {
        SDL_SetCursor(newCursor);
        mCurrentCursor = newCursor;
        return true;
    }

    return false;
}

bool CursorManager::SetDefaultCursor() {
    return SetCursor(CursorType::ARROW);
}

SDL_Cursor* CursorManager::GetSystemCursor(CursorType type) {
    auto it = mSystemCursors.find(type);
    return (it != mSystemCursors.end()) ? it->second : nullptr;
}

bool CursorManager::LoadCustomCursor(const std::string& name,
    const std::string& imagePath,
    int hotX, int hotY) {
    // ����ͼ��
    SDL_Surface* surface = SDL_LoadBMP(imagePath.c_str());
    if (!surface) {
        std::cerr << "Failed to load cursor image: " << imagePath
            << " - " << SDL_GetError() << std::endl;
        return false;
    }

    return LoadCustomCursorFromSurface(name, surface, hotX, hotY);
}

bool CursorManager::LoadCustomCursorFromSurface(const std::string& name,
    SDL_Surface* surface,
    int hotX, int hotY) {
    if (!surface) return false;

    // ȷ�������ʽ��ȷ����Ҫ��ɫλͼ��
    // SDL_CreateCursor��Ҫλͼ���ݣ�����򻯴���
    // ʵ����Ŀ�п�����Ҫת�������ʽ

    // ����λͼ���ݣ���ʾ����
    int width = surface->w;
    int height = surface->h;

    // ������ת��Ϊ��ɫλͼ��ʵ��ʵ�ֻ�����ӣ�
    // ����ֻ��ʾ����ʵ����Ҫ��ȷ����alphaͨ������ɫ��

    // ������꣨ʵ��Ӧ�ø��ݱ������ݴ�����
    SDL_Cursor* cursor = SDL_CreateColorCursor(surface, hotX, hotY);

    if (!cursor) {
        std::cerr << "Failed to create custom cursor: " << name
            << " - " << SDL_GetError() << std::endl;
        return false;
    }

    // �洢���
    RemoveCustomCursor(name); // ����Ѵ��ڣ����Ƴ�
    mCustomCursors[name] = cursor;

    return true;
}

bool CursorManager::RemoveCustomCursor(const std::string& name) {
    auto it = mCustomCursors.find(name);
    if (it != mCustomCursors.end()) {
        if (mCurrentCursor == it->second) {
            SetDefaultCursor();
        }
        SDL_FreeCursor(it->second);
        mCustomCursors.erase(it);
        return true;
    }
    return false;
}

void CursorManager::ShowCursor() {
    if (mCursorHidden) {
        SDL_ShowCursor(SDL_ENABLE);
        mCursorHidden = false;
    }
}

void CursorManager::HideCursor() {
    if (!mCursorHidden) {
        SDL_ShowCursor(SDL_DISABLE);
        mCursorHidden = true;
    }
}

CursorType CursorManager::GetCurrentCursorType() const {
    // ���ҵ�ǰ����Ӧ������
    for (const auto& [type, cursor] : mSystemCursors) {
        if (cursor == mCurrentCursor) {
            return type;
        }
    }

    // ����Ƿ�Ϊ�Զ�����
    for (const auto& [name, cursor] : mCustomCursors) {
        if (cursor == mCurrentCursor) {
            return CursorType::CUSTOM;
        }
    }

    return CursorType::ARROW; // Ĭ��
}

void CursorManager::Update() {
    if (m_forceUpdate) {
        if (m_hoverCount > 0) {
            SetCursor(CursorType::HAND);
        }
        else {
            SetDefaultCursor();
        }
        m_forceUpdate = false;
    }
}

void CursorManager::ForceUpdateCursor() {
    if (mCurrentCursor) {
        SDL_SetCursor(mCurrentCursor);
    }
}