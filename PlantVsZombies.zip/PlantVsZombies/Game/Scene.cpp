#include "Scene.h"
#include "GameObjectManager.h"
#include "CollisionSystem.h"
#include "../ResourceManager.h"
#include "../ParticleSystem/ParticleSystem.h"
#include "ClickableComponent.h"
#include "../GameApp.h"
#include <iostream>

void Scene::BuildDrawCommands() {
    mDrawCommands.clear();

	// ����������������
    RegisterDrawCommand("GameTextures",
        [this](SDL_Renderer* renderer) { this->DrawAllTextures(renderer); },
        LAYER_BACKGROUND);

    // ������Ϸ�����������
    RegisterDrawCommand("GameObjects",
        [this](SDL_Renderer* renderer) { this->DrawGameObjects(renderer); },
        LAYER_GAME_OBJECT);

    // ע������ϵͳ����
    RegisterDrawCommand("ParticleSystem",
        [](SDL_Renderer* renderer) {
            if (g_particleSystem) {
                g_particleSystem->DrawAll();
            }
        },
        LAYER_EFFECTS);

    // ����UI��������
    RegisterDrawCommand("UI",
        [this](SDL_Renderer* renderer) { this->mUIManager.DrawAll(renderer); },
        LAYER_UI);
}

void Scene::RegisterDrawCommand(const std::string& name,
    std::function<void(SDL_Renderer*)> drawFunc,
    int renderOrder) 
{
    auto it = std::find_if(mDrawCommands.begin(), mDrawCommands.end(),
        [&name](const DrawCommand& cmd) { return cmd.name == name; });

    if (it != mDrawCommands.end()) {
        it->drawFunc = drawFunc;
        it->renderOrder = renderOrder;
    }
    else {
        mDrawCommands.emplace_back(drawFunc, renderOrder, name);
    }
}

void Scene::Draw(SDL_Renderer* renderer) {
    if (!mDrawCommandsBuilt) {
        BuildDrawCommands();
        mDrawCommandsBuilt = true;
    }
    for (auto& cmd : mDrawCommands) {
        if (cmd.drawFunc) {
            cmd.drawFunc(renderer);
        }
    }
}

void Scene::Update()
{
    if (g_particleSystem) 
    {
        g_particleSystem->UpdateAll();
    }
    auto input = &GameAPP::GetInstance().GetInputHandler();
	mUIManager.ProcessMouseEvent(input);
	mUIManager.UpdateAll(input);
    GameObjectManager::GetInstance().Update();
    ClickableComponent::ProcessMouseEvents();
    CollisionSystem::GetInstance().Update();
}

void Scene::UnregisterDrawCommand(const std::string& name) {
    auto it = std::remove_if(mDrawCommands.begin(), mDrawCommands.end(),
        [&name](const DrawCommand& cmd) { return cmd.name == name; });
    mDrawCommands.erase(it, mDrawCommands.end());
}

void Scene::AddTexture(const std::string& textureName, float posX, float posY, float scaleX, float scaleY, int drawOrder, bool isUI) {
    SDL_Texture* texture = ResourceManager::GetInstance().GetTexture(textureName);
    if (texture) {
        TextureInfo info{ texture, posX, posY };
        info.scaleX = scaleX;
        info.scaleY = scaleY;
        info.drawOrder = drawOrder;
        info.name = textureName;              
        info.isUI = isUI;                   
        mTextures.push_back(info);
#ifdef _DEBUG
        std::cout << "���� " << name << " ��������: " << textureName
            << " λ��: (" << posX << ", " << posY << ")"
            << " ����X:" << scaleX << "Y:" << scaleY << std::endl;
#endif
    }
    else {
        std::cerr << "���� " << name << " �޷���������: " << textureName << std::endl;
    }
}

void Scene::RemoveTexture(const std::string& textureName) {
    auto it = std::find_if(mTextures.begin(), mTextures.end(),
        [&textureName](const TextureInfo& info) {
            return info.name == textureName;
        });

    if (it != mTextures.end()) {
#ifdef _DEBUG
        std::cout << "���� " << name << " �Ƴ�����: " << textureName << std::endl;
#endif
        mTextures.erase(it);
    }
}

void Scene::SetTexturePosition(const std::string& textureName, float posX, float posY) {
    auto it = std::find_if(mTextures.begin(), mTextures.end(),
        [&textureName](const TextureInfo& info) {
            return info.name == textureName;
        });

    if (it != mTextures.end()) {
        it->posX = posX;
        it->posY = posY;
    }
}

void Scene::SetTextureScale(const std::string& textureName, float scaleX, float scaleY) {
    auto it = std::find_if(mTextures.begin(), mTextures.end(),
        [&textureName](const TextureInfo& info) {
            return info.name == textureName;
        });

    if (it != mTextures.end()) {
        it->scaleX = scaleX;
        it->scaleY = scaleY;
    }
}

void Scene::SetTextureScaleX(const std::string& textureName, float scaleX) {
    auto it = std::find_if(mTextures.begin(), mTextures.end(),
        [&textureName](const TextureInfo& info) {
            return info.name == textureName;
        });

    if (it != mTextures.end()) {
        it->scaleX = scaleX;
    }
}

void Scene::SetTextureScaleY(const std::string& textureName, float scaleY) {
    auto it = std::find_if(mTextures.begin(), mTextures.end(),
        [&textureName](const TextureInfo& info) {
            return info.name == textureName;
        });

    if (it != mTextures.end()) {
        it->scaleY = scaleY;
    }
}

void Scene::SetTextureVisible(const std::string& textureName, bool visible) {
    auto it = std::find_if(mTextures.begin(), mTextures.end(),
        [&textureName](const TextureInfo& info) {
            return info.name == textureName;
        });

    if (it != mTextures.end()) {
        it->visible = visible;
    }
}

void Scene::SetTextureDrawOrder(const std::string& textureName, int drawOrder) {
    auto it = std::find_if(mTextures.begin(), mTextures.end(),
        [&textureName](const TextureInfo& info) {
            return info.name == textureName;
        });

    if (it != mTextures.end()) {
        it->drawOrder = drawOrder;
    }
}

void Scene::ClearAllTextures() {
#ifdef _DEBUG
    std::cout << "���� " << name << " �����������" << std::endl;
#endif
    mTextures.clear();
}

void Scene::DrawAllTextures(SDL_Renderer* renderer) {
    // ������˳������
    std::sort(mTextures.begin(), mTextures.end(),
        [](const TextureInfo& a, const TextureInfo& b) {
            return a.drawOrder < b.drawOrder;
        });

    auto& camera = GameAPP::GetInstance().GetCamera();
    // �������пɼ�����
    for (size_t i = 0; i < mTextures.size(); i++)
    {
		auto texInfo = mTextures[i];
        if (!texInfo.visible) continue;

        int texWidth, texHeight;
        SDL_QueryTexture(texInfo.texture, nullptr, nullptr, &texWidth, &texHeight);

        float displayWidth = texWidth * texInfo.scaleX;
        float displayHeight = texHeight * texInfo.scaleY;

        float drawX = texInfo.posX;
        float drawY = texInfo.posY;

        if (!texInfo.isUI) {
            Vector worldPos(texInfo.posX, texInfo.posY);
            Vector screenPos = camera.WorldToScreen(worldPos);
            drawX = screenPos.x;
            drawY = screenPos.y;
        }

        SDL_FRect destRect = { drawX, drawY, displayWidth, displayHeight };
        SDL_RenderCopyF(renderer, texInfo.texture, nullptr, &destRect);
    }
}

TextureInfo* Scene::GetTextureInfo(const std::string& textureName) {
    auto it = std::find_if(mTextures.begin(), mTextures.end(),
        [&textureName](const TextureInfo& info) {
            return info.name == textureName;
        });

    return it != mTextures.end() ? &(*it) : nullptr;
}