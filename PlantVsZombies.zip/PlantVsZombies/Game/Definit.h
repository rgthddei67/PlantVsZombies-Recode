#pragma once
#ifndef _DEFINIT_H
#define _DEFINIT_H

#define GLM_ENABLE_EXPERIMENTAL
#include <glm/glm.hpp>
#include <SDL2/SDL.h>
#include <math.h>

struct Vector
{
    float x;
    float y;
    Vector()
    {
        x = 0, y = 0;
    }
    Vector(float x, float y)
    {
        this->x = x;
        this->y = y;
    }
    operator SDL_FPoint() const 
    { 
        return { x, y }; 
    }
    Vector(const glm::vec2& vec) : x(vec.x), y(vec.y) {}
    operator glm::vec2() const { return glm::vec2(x, y); }

    Vector(const glm::vec4& vec) : x(vec.x), y(vec.y) {}
    SDL_FPoint ToSDL_FPoint() const {
        return { x, y };
    }
    bool operator==(const Vector& other) const {
        return x == other.x && y == other.y;
    }
    bool operator!=(const Vector& other) const {
        return !(*this == other);
    }
    bool operator<(const Vector& other) const {
        if (x != other.x) return x < other.x;
        return y < other.y;
    }
    bool operator>(const Vector& other) const {
        if (x != other.x) return x > other.x;
        return y > other.y;
    }
    Vector operator+(const Vector& other) const {
        return Vector(x + other.x, y + other.y);
    }
    Vector operator-(const Vector& other) const {
        return Vector(x - other.x, y - other.y);
    }
    Vector operator+(const glm::vec2& other) const {
        return Vector(x + other.x, y + other.y);
    }
    Vector operator-(const glm::vec2& other) const {
        return Vector(x - other.x, y - other.y);
    }
    Vector operator*(float scalar) const {
        return Vector(x * scalar, y * scalar);
    }
    Vector operator/(float scalar) const {
        return Vector(x / scalar, y / scalar);
    }
    Vector& operator+=(const Vector& other) {
        x += other.x;
        y += other.y;
        return *this;
    }
    Vector& operator-=(const Vector& other) {
        x -= other.x;
        y -= other.y;
        return *this;
    }
    Vector& operator*=(float scalar) {
        x *= scalar;
        y *= scalar;
        return *this;
    }
    Vector& operator/=(float scalar) {
        x /= scalar;
        y /= scalar;
        return *this;
    }
    // �����������ȣ�ģ��
    float magnitude() const {
        return sqrtf(x * x + y * y);
    }
    // �����������ȵ�ƽ�������⿪�����㣬���ڱȽϳ���ʱ����Ч��
    float sqrMagnitude() const {
        return x * x + y * y;
    }
    // ��һ��������ʹ�䳤��Ϊ1��
    Vector normalized() const {
        float mag = magnitude();
        if (mag > 0) {
            return Vector(x / mag, y / mag);
        }
        return Vector(0, 0);
    }
    // ������ڻ���
    float dot(const Vector& other) const {
        return x * other.x + y * other.y;
    }
    // ��������֮��ľ���
    static float distance(const Vector& a, const Vector& b) {
        return (a - b).magnitude();
    }
    // ��������֮������ƽ��
    static float sqrDistance(const Vector& a, const Vector& b) {
        return (a - b).sqrMagnitude();
    }
    // ���Բ�ֵ
    static Vector lerp(const Vector& a, const Vector& b, float t) {
        t = (t < 0) ? 0 : (t > 1) ? 1 : t; // ����t��0-1֮��
        return a + (b - a) * t;
    }

    static Vector zero() { return Vector(0, 0); }
    static Vector one() { return Vector(1, 1); }
    static Vector up() { return Vector(0, -1); } // ��Ļ����ϵ��Y������Ϊ��
    static Vector down() { return Vector(0, 1); }
    static Vector left() { return Vector(-1, 0); }
    static Vector right() { return Vector(1, 0); }
};

using Matrix4 = glm::mat4;
using Matrix3 = glm::mat3;

inline Vector TransformPoint(const Vector& point, const glm::mat4& matrix) {
    glm::vec4 result = matrix * glm::vec4(point.x, point.y, 0.0f, 1.0f);
    return Vector(result.x, result.y);
}

#endif