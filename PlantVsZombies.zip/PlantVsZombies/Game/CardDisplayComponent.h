#pragma once
#ifndef _CARD_DISPLAY_COMPONENT_H
#define _CARD_DISPLAY_COMPONENT_H

#include "Component.h"
#include "./Plant/PlantType.h"
#include <SDL2/SDL.h>
#include <string>

// ����״̬ö��
enum class CardState
{
    Cooling = 0,
    Ready = 1,
    WaitingSun = 2,
    Click = 3,
};

class CardComponent;
class TransformComponent;

class CardDisplayComponent : public Component {
private:
    // ������Դ
    SDL_Texture* cardBackground = nullptr;    // IMAGE_card_bk
    SDL_Texture* cardNormal = nullptr;        // IMAGE_SeedPacketNormal
    SDL_Texture* plantTexture = nullptr;      // ֲ��ͼƬ

	mutable std::weak_ptr<CardComponent> mCardComponent;
	mutable std::weak_ptr<TransformComponent> mTransformComponent;

    // ״̬���
    CardState cardState = CardState::Cooling;
    PlantType plantType;
    int needSun = 0;
    float cooldownTime = 0;
    float currentCooldown = 0;
    bool isSelected = false;

    // ��ȴ�������
    float maskFillAmount = 1.0f;
    bool showMask = true;

    // ��ɫ״̬
    SDL_Color readyColor = { 255, 255, 255, 255 };      // ��ɫ - ����
    SDL_Color disabledColor = { 160, 160, 160, 255 };   // ��ɫ - ����/��ȴ
    SDL_Color waitingSunColor = { 215, 215, 215, 255 }; // ǳ��ɫ - �ȴ�����
    SDL_Color clickColor = { 160, 160, 160, 255 };         // ���ɫ - ���״̬

public:
    CardDisplayComponent(PlantType type, int sunCost, float cooldown);

    void Start() override;
    void Update() override;
    void Draw(SDL_Renderer* renderer) override;

    // ״̬ת��
    void TranToWaitingSun();
    void TranToReady();
    void TranToCooling();
    void TranToClick();

    // ״̬����
    void UpdateCardState();
    void UpdateCooldown(float deltaTime);

    // ����״̬
    void SetSelected(bool selected) { isSelected = selected; }
    void SetCooldownProgress(float progress) { maskFillAmount = progress; }
    void SetNeedSun(int sun) { needSun = sun; }

    // ��ȡ״̬
    int GetNeedSun() const { return needSun; }
    PlantType GetPlantType() const { return plantType; }
    CardState GetCardState() const { return cardState; }
    bool IsReady() const { return cardState == CardState::Ready; }
    bool IsCooling() const { return cardState == CardState::Cooling; }

	std::shared_ptr<CardComponent> GetCardComponent() const;
	std::shared_ptr<TransformComponent> GetTransformComponent() const;

private:
    void LoadTextures();
    void DrawCardBackground(SDL_Renderer* renderer, std::shared_ptr<TransformComponent> transform);
    void DrawPlantImage(SDL_Renderer* renderer, std::shared_ptr<TransformComponent> transform);
    void DrawCooldownMask(SDL_Renderer* renderer, std::shared_ptr<TransformComponent> transform);
    void DrawSunCost(SDL_Renderer* renderer, std::shared_ptr<TransformComponent> transform);
    void DrawSelectionHighlight(SDL_Renderer* renderer, std::shared_ptr<TransformComponent> transform);

    SDL_Color GetCurrentColor() const;
    std::string GetPlantTextureKey() const;
};

#endif