#include "ChooseCardUI.h"
#include "SceneManager.h"
#include "../ResourceKeys.h"
#include "../ResourceManager.h"
#include "GameScene.h"
#include "./Plant/PlantType.h"
#include "./Plant/GameDataManager.h"
#include "./AudioSystem.h"
#include "../GameRandom.h"
#include "CardSlotManager.h"
#include <memory>

ChooseCardUI::ChooseCardUI(GameScene* gameScene)
{
	this->SetName("ChooseCardUI");
	mCards.reserve(64);
	mSelectedCards.reserve(16);
	mGameScene = gameScene;
	if (!mGameScene) return;
	mTransform = AddComponent<TransformComponent>(60.0f, 800.0f);
	mCardUITexture = ResourceManager::GetInstance().
		GetTexture(ResourceKeys::Textures::IMAGE_SEEDCHOOSER_BACKGROUND);
	auto button = mGameScene->GetUIManager().CreateButton
	(Vector(400, 550),
		Vector(156 * 0.9f, 42 * 0.9f));
	mButton = button;
	button->SetAsCheckbox(false);
	button->SetImageKeys(ResourceKeys::Textures::IMAGE_SEEDCHOOSER_BUTTON_DISABLED,
		ResourceKeys::Textures::IMAGE_SEEDCHOOSER_BUTTON,
		ResourceKeys::Textures::IMAGE_SEEDCHOOSER_BUTTON);
	button->SetTextColor(SDL_Color{ 211, 157, 42 ,255 });
	button->SetHoverTextColor(SDL_Color{ 211, 157, 42 ,255 });
	button->SetText(u8"     һ��ҡ���ɣ�", ResourceKeys::Fonts::FONT_FZCQ, 20);
	button->SetEnabled(false);
	button->SetClickCallBack([this](bool isChecked) {
		if (mGameScene) {
			mGameScene->ChooseCardComplete();
		}
		});
}

ChooseCardUI::~ChooseCardUI() {
	SceneManager::GetInstance().GetCurrectSceneUIManager().RemoveButton(mButton.lock());
	mGameScene = nullptr;
	//TODO ����������ʱ���������������û�����٣���Ҫ�����ʱ�����٣���Ϊû��
}

void ChooseCardUI::RemoveAllCards() {
	for (auto& card : mCards) {
		GameObjectManager::GetInstance().DestroyGameObject(card);
	}
	mCards.clear();
	mSelectedCards.clear();
}

void ChooseCardUI::TransferSelectedCardsTo(CardSlotManager* manager) {
	for (auto& card : mSelectedCards) {
		// ���ÿ���״̬Ϊ��Ϸ��
		card->SetIsInChooseCardUI(false);
		if (auto comp = card->GetCardComponent()) {
			comp->SetIsInChooseCardUI(false);
			comp->SetCardGameClick(card);
		}
		// ���ӵ����۹�����
		if (manager) {
			manager->AddCard(card);
		}
		// �� mCards ���Ƴ�
		auto it = std::find(mCards.begin(), mCards.end(), card);
		if (it != mCards.end()) {
			mCards.erase(it);
		}
	}
	mSelectedCards.clear();
}

void ChooseCardUI::Draw(SDL_Renderer* renderer) {
	// ���Ʊ���
	if (mCardUITexture) {
		Vector pos = this->GetPosition();
		int w, h;
		SDL_QueryTexture(mCardUITexture, nullptr, nullptr, &w, &h);
		SDL_FRect dest =
		{
		pos.x,
		pos.y,
		static_cast<float>(w),
		static_cast<float>(h) };
		SDL_RenderCopyF(renderer, mCardUITexture, nullptr, &dest);
	}
}

void ChooseCardUI::AddCard(PlantType type) {

	// ���㵱ǰ����������Ӧ������
	int cardCount = static_cast<int>(mCards.size());
	int row = cardCount / MAX_CARDS_PER_ROW;
	int col = cardCount % MAX_CARDS_PER_ROW;

	// ����λ��
	float posX = START_X + col * (CARD_WIDTH + CARD_HORIZONTAL_SPACING);
	float posY = START_Y + row * (CARD_HEIGHT + CARD_VERTICAL_SPACING);

	auto& gameMgr = GameDataManager::GetInstance();

	auto card = GameObjectManager::GetInstance().
		CreateGameObjectImmediate<Card>(LAYER_UI, type,
			gameMgr.GetPlantSunCost(type), gameMgr.GetPlantCooldown(type), true);

	if (auto transform = card->GetComponent<TransformComponent>()) {
		transform->SetPosition(Vector(posX, posY));
	}
	card->SetOriginalPosition(Vector(posX, posY));
	card->mIsUI = true;
	mCards.push_back(card);
}

void ChooseCardUI::RemoveCard(std::shared_ptr<Card> card)
{
	auto it = std::find(mCards.begin(), mCards.end(), card);
	if (it != mCards.end()) {
		mCards.erase(it);
		
	}

	// �����ѡ�У�Ҳ��ѡ���б����Ƴ�
	auto selIt = std::find(mSelectedCards.begin(), mSelectedCards.end(), card);
	if (selIt != mSelectedCards.end()) {
		mSelectedCards.erase(selIt);
		UpdateTargetPositions();
	}

	GameObjectManager::GetInstance().DestroyGameObject(card);
}

void ChooseCardUI::AddAllCard() {
	for (int i = 0; i < static_cast<int>(PlantType::PLANT_CHERRYBOMB); ++i) {
		AddCard(static_cast<PlantType>(i));
	}
}

bool ChooseCardUI::ToggleCardSelection(std::shared_ptr<Card> card) {
	if (!card) return false;

	auto it = std::find(mSelectedCards.begin(), mSelectedCards.end(), card);
	if (it != mSelectedCards.end()) {
		// ��ѡ�� -> �Ƴ�
		mSelectedCards.erase(it);
		UpdateTargetPositions();
		return false;
	}
	else {
		// δѡ�� -> ���ӣ������������
		if (mSelectedCards.size() >= MAX_SELECTED) {
			return false;
		}
		mSelectedCards.push_back(card);
		UpdateTargetPositions();
		return true;
	}
}

void ChooseCardUI::UpdateTargetPositions() {
	// Ϊ���п��Ƽ���Ŀ��λ��
	int random = GameRandom::Range(0, 1);
	if (random == 0)
	{
		AudioSystem::PlaySound
		(ResourceKeys::Sounds::SOUND_CHOOSEPLANT1, 0.4f);
	}
	else
	{
		AudioSystem::PlaySound
		(ResourceKeys::Sounds::SOUND_CHOOSEPLANT2, 0.4f);
	}

	for (size_t i = 0; i < mCards.size(); ++i) {
		auto card = mCards[i];
		Vector targetPos = Vector(0, 0);
		// ����Ƿ���ѡ���б���
		auto it = std::find(mSelectedCards.begin(), mSelectedCards.end(), card);
		if (it != mSelectedCards.end()) {
			// �������б��е����������λλ��
			int index = static_cast<int>(it - mSelectedCards.begin());
			targetPos.x = SLOT_START_X + index * SLOT_SPACING;
			targetPos.y = SLOT_START_Y;
		}
		else {
			// ����ԭʼλ��
			targetPos = card->GetOriginalPosition();
		}
		// ����Ŀ��λ�ã���������
		card->SetTargetPosition(targetPos);
	}
}

bool ChooseCardUI::IsCardSelected(std::shared_ptr<Card> card) const {
	return std::find(mSelectedCards.begin(), mSelectedCards.end(), card) != mSelectedCards.end();
}