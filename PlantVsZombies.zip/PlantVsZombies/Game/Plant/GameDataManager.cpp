#include "GameDataManager.h"
#include "../../ResourceKeys.h"
#include <iostream>
#include <algorithm>
#include <vector>

GameDataManager::GameDataManager() {}

void GameDataManager::Initialize() {
	// �����������
	mPlantInfo.clear();
	mZombieInfo.clear();
	mAnimToString.clear();
	mEnumNameToType.clear();
	mTextureKeyToType.clear();
	mAnimNameToType.clear();

	InitializeHardcodedData();

	std::cout << "[GameDataManager] ��ʼ����ɣ���ע�� "
		<< mPlantInfo.size() << " ��ֲ�"
		<< mZombieInfo.size() << " �ֽ�ʬ" << std::endl;
}

void GameDataManager::InitializeHardcodedData() {
	// ==================== ֲ��ע�� ====================
	RegisterPlant(
		PlantType::PLANT_SUNFLOWER,
		50, 7.5f,
		"PLANT_SUNFLOWER",
		ResourceKeys::Textures::IMAGE_SUNFLOWER,
		AnimationType::ANIM_SUNFLOWER,
		ResourceKeys::Reanimations::REANIM_SUNFLOWER,
		Vector(-37.6f, -44)
	);

	RegisterPlant(
		PlantType::PLANT_PEASHOOTER,
		100, 7.5f,
		"PLANT_PEASHOOTER",
		ResourceKeys::Textures::IMAGE_PEASHOOTER,
		AnimationType::ANIM_PEASHOOTER,
		ResourceKeys::Reanimations::REANIM_PEASHOOTER,
		Vector(-37.6f, -44)
	);


	// ==================== ��ʬע�� ====================
	// ��ͨ��ʬ
	RegisterZombie(
		ZombieType::ZOMBIE_NORMAL,
		"ZOMBIE_NORMAL",
		AnimationType::ANIM_NORMAL_ZOMBIE,
		ResourceKeys::Reanimations::REANIM_NORMAL_ZOMBIE,
		Vector(-50, -85),
		1,
		1
	);

	// ==================== ��ֲ��/��ʬ����ӳ�� ====================
	mAnimToString[AnimationType::ANIM_SUN] = ResourceKeys::Reanimations::REANIM_SUN;
	mAnimToString[AnimationType::ANIM_NONE] = "Unknown";
}

void GameDataManager::RegisterPlant(PlantType type,
	int sunCost, float cooldown,
	const std::string& enumName,
	const std::string& textureKey,
	AnimationType animType,
	const std::string& animName,
	const Vector& offset) {
	PlantInfo info(type, sunCost, cooldown, enumName, textureKey, animType, animName, offset);
	mPlantInfo[type] = info;

	mEnumNameToType[enumName] = type;
	mTextureKeyToType[textureKey] = type;
	mAnimNameToType[animName] = type;

	mAnimToString[animType] = animName;

#ifdef _DEBUG
	std::cout << "[GameDataManager] ע��ֲ��: " << animName
		<< " (ƫ��: " << offset.x << ", " << offset.y << ")" << std::endl;
#endif
}

void GameDataManager::RegisterZombie(ZombieType type,
	const std::string& enumName,
	AnimationType animType,
	const std::string& animName,
	const Vector& offset, int weight, int appearWave) {
	ZombieInfo info(type, enumName, animType, animName, offset, weight, appearWave);
	mZombieInfo[type] = info;

	// ��¼��������->��Դ�����Ա�ͨ�� AnimationType ͳһ��ѯ
	mAnimToString[animType] = animName;

#ifdef _DEBUG
	std::cout << "[GameDataManager] ע�Ὡʬ: " << animName
		<< " (ƫ��: " << offset.x << ", " << offset.y << ")" << std::endl;
#endif
}

std::string GameDataManager::GetPlantTextureKey(PlantType plantType) const {
	auto it = mPlantInfo.find(plantType);
	if (it != mPlantInfo.end())
		return it->second.textureKey;
	return "IMAGE_PLANT_DEFAULT";
}

AnimationType GameDataManager::GetPlantAnimationType(PlantType plantType) const {
	auto it = mPlantInfo.find(plantType);
	if (it != mPlantInfo.end())
		return it->second.animType;
	return AnimationType::ANIM_NONE;
}

std::string GameDataManager::GetAnimationName(AnimationType animType) const {
	// ������ֲ�ﶯ���в���
	for (const auto& pair : mPlantInfo) {
		if (pair.second.animType == animType)
			return pair.second.animName;
	}
	// Ȼ���ڽ�ʬ�����в���
	for (const auto& pair : mZombieInfo) {
		if (pair.second.animType == animType)
			return pair.second.animName;
	}
	// �����ͨ��ӳ���в���
	auto it = mAnimToString.find(animType);
	if (it != mAnimToString.end())
		return it->second;
	return "Unknown";
}

Vector GameDataManager::GetPlantOffset(PlantType plantType) const {
	auto it = mPlantInfo.find(plantType);
	if (it != mPlantInfo.end())
		return it->second.offset;
	return Vector(0, 0);
}

void GameDataManager::SetPlantOffset(PlantType plantType, const Vector& offset) {
	auto it = mPlantInfo.find(plantType);
	if (it != mPlantInfo.end()) {
		it->second.offset = offset;
#ifdef _DEBUG
		std::cout << "[GameDataManager] ����ֲ��ƫ��: " << it->second.animName
			<< " -> (" << offset.x << ", " << offset.y << ")" << std::endl;
#endif
	}
}

std::string GameDataManager::PlantTypeToEnumName(PlantType type) const {
	auto it = mPlantInfo.find(type);
	if (it != mPlantInfo.end())
		return it->second.enumName;
	return "PLANT_NONE";
}

std::string GameDataManager::PlantTypeToTextureKey(PlantType type) const {
	return GetPlantTextureKey(type);
}

std::string GameDataManager::PlantTypeToAnimName(PlantType type) const {
	auto it = mPlantInfo.find(type);
	if (it != mPlantInfo.end())
		return it->second.animName;
	return "Unknown";
}

PlantType GameDataManager::StringToPlantType(const std::string& str) const {
	auto enumIt = mEnumNameToType.find(str);
	if (enumIt != mEnumNameToType.end())
		return enumIt->second;

	auto texIt = mTextureKeyToType.find(str);
	if (texIt != mTextureKeyToType.end())
		return texIt->second;

	auto animIt = mAnimNameToType.find(str);
	if (animIt != mAnimNameToType.end())
		return animIt->second;

	return PlantType::NUM_PLANT_TYPES;
}

std::vector<PlantType> GameDataManager::GetAllPlantTypes() const {
	std::vector<PlantType> types;
	for (const auto& pair : mPlantInfo)
		types.push_back(pair.first);
	return types;
}

bool GameDataManager::HasPlant(PlantType type) const {
	return mPlantInfo.find(type) != mPlantInfo.end();
}

int GameDataManager::GetPlantSunCost(PlantType plantType) const {
	auto it = mPlantInfo.find(plantType);
	if (it != mPlantInfo.end())
		return it->second.SunCost;
	return 0;
}

float GameDataManager::GetPlantCooldown(PlantType plantType) const {
	auto it = mPlantInfo.find(plantType);
	if (it != mPlantInfo.end())
		return it->second.Cooldown;
	return 0.0f;
}

AnimationType GameDataManager::GetZombieAnimationType(ZombieType zombieType) const {
	auto it = mZombieInfo.find(zombieType);
	if (it != mZombieInfo.end())
		return it->second.animType;
	return AnimationType::ANIM_NONE;
}

std::string GameDataManager::GetZombieAnimName(ZombieType zombieType) const {
	auto it = mZombieInfo.find(zombieType);
	if (it != mZombieInfo.end())
		return it->second.animName;
	return "Unknown";
}

Vector GameDataManager::GetZombieOffset(ZombieType zombieType) const {
	auto it = mZombieInfo.find(zombieType);
	if (it != mZombieInfo.end())
		return it->second.offset;
	return Vector(0, 0);
}

void GameDataManager::SetZombieOffset(ZombieType zombieType, const Vector& offset) {
	auto it = mZombieInfo.find(zombieType);
	if (it != mZombieInfo.end()) {
		it->second.offset = offset;
#ifdef _DEBUG
		std::cout << "[GameDataManager] ���ý�ʬƫ��: " << it->second.animName
			<< " -> (" << offset.x << ", " << offset.y << ")" << std::endl;
#endif
	}
}

int GameDataManager::GetZombieWeight(ZombieType zombieType) const
{
	auto it = mZombieInfo.find(zombieType);
	if (it != mZombieInfo.end())
		return it->second.weight;
	return 0;
}

int GameDataManager::GetZombieAppearWave(ZombieType zombieType) const
{
	auto it = mZombieInfo.find(zombieType);
	if (it != mZombieInfo.end())
		return it->second.appearWave;
	return 0;
}

std::vector<ZombieType> GameDataManager::GetAllZombieTypes() const {
	std::vector<ZombieType> types;
	for (const auto& pair : mZombieInfo)
		types.push_back(pair.first);
	return types;
}

bool GameDataManager::HasZombie(ZombieType type) const {
	return mZombieInfo.find(type) != mZombieInfo.end();
}

void GameDataManager::DebugPrintAll() const {
	std::cout << "========== GameDataManager Ӳ�������� ==========" << std::endl;
	std::cout << "ֲ������: " << mPlantInfo.size() << std::endl;
	for (const auto& pair : mPlantInfo) {
		const PlantInfo& info = pair.second;
		std::cout << "ֲ��: " << info.animName << " (" << info.enumName << ")" << std::endl;
		std::cout << "  ������: " << info.textureKey << std::endl;
		std::cout << "  ��������: " << static_cast<int>(info.animType) << std::endl;
		std::cout << "  ƫ����: (" << info.offset.x << ", " << info.offset.y << ")" << std::endl;
	}

	std::cout << "\n��ʬ����: " << mZombieInfo.size() << std::endl;
	for (const auto& pair : mZombieInfo) {
		const ZombieInfo& info = pair.second;
		std::cout << "��ʬ: " << info.animName << " (" << info.enumName << ")" << std::endl;
		std::cout << "  ��������: " << static_cast<int>(info.animType) << std::endl;
		std::cout << "  ƫ����: (" << info.offset.x << ", " << info.offset.y << ")" << std::endl;
	}
	std::cout << "=============================================" << std::endl;
}