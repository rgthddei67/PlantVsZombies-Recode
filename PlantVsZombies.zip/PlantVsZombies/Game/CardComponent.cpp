#include "CardComponent.h"
#include "../ResourceKeys.h"
#include "CardDisplayComponent.h"
#include "ClickableComponent.h"
#include "GameObject.h"
#include "GameObjectManager.h"
#include "./CardSlotManager.h"
#include "../DeltaTime.h"
#include "./ChooseCardUI.h"
#include "AudioSystem.h"

CardComponent::CardComponent(PlantType type, int cost, float cooldown)
	: mPlantType(type), mSunCost(cost), mCooldownTime(cooldown)
{
	mCooldownTimer = 0.0f;
}

void CardComponent::Start() {
	if (auto manager = FindCardSlotManager()) {
		mCardSlotManager = manager;
	}

	auto gameObject = GetGameObject();

	auto card = std::dynamic_pointer_cast<Card>(gameObject);
	if (!card) return;

	mIsInChooseCardUI = card->GetIsInChooseCardUI();
	if (mIsInChooseCardUI) {
		SetCardChooseClick(gameObject, card);
	}
	else
	{
		SetCardGameClick(gameObject);
	}
}

void CardComponent::SetCardChooseClick(std::shared_ptr<GameObject> gameObject, 
	std::shared_ptr<Card> card)
{
	if (auto clickable = gameObject->GetComponent<ClickableComponent>()) {
		// ---------- ѡ���������߼� ----------
		clickable->onClick = [this, card]() {
			if (card->IsMoving()) return;

			// ���� ChooseCardUI
			auto& manager = GameObjectManager::GetInstance();
			std::shared_ptr<ChooseCardUI> chooseUI;
			for (auto obj : manager.GetAllGameObjects()) {
				if (obj && obj->GetName() == "ChooseCardUI") {
					chooseUI = std::dynamic_pointer_cast<ChooseCardUI>(obj);
					break;
				}
			}

			if (!chooseUI) {
				std::cerr << "ChooseCardUI not found!" << std::endl;
				return;
			}

			// �л�ѡ��״̬
			bool isPickedUp = chooseUI->ToggleCardSelection(card);

			};
	}
}

void CardComponent::SetCardGameClick(std::shared_ptr<GameObject> gameObject)
{
	// ����CardDisplayComponent��û�д����ã����Բ��ܻ��� �ŵ�GetCardDisplayComponent�����
	// ��ȡ�����������ûص�
	if (auto clickable = gameObject->GetComponent<ClickableComponent>()) {
		clickable->onClick = [this]() {
			// ֪ͨ���۹�����������Ʊ������
			auto manager = GetCardSlotManager();
			if (!IsReady() || !manager->CanAfford(mSunCost)) {
				AudioSystem::PlaySound(ResourceKeys::Sounds::SOUND_CLICKFAILED, 0.5f);
				return;
			}
			manager->SelectCard(this->GetGameObject());
			AudioSystem::PlaySound(ResourceKeys::Sounds::SOUND_CLICKSEED, 0.5f);
			};
	}
}

void CardComponent::Update() {
	if (mIsInChooseCardUI) return;
	// ������ȴ
	if (mIsCooldown) {
		mCooldownTimer -= DeltaTime::GetDeltaTime();
		if (mCooldownTimer <= 0) {
			mIsCooldown = false;
			mCooldownTimer = 0;
			// ��ȴ������ǿ�Ƹ���״̬
			ForceStateUpdate();
		}
		else {
			// ������ȴ������ʾ
			if (auto display = GetCardDisplayComponent()) {
				float progress = 1.0f - (mCooldownTimer / mCooldownTime);
				display->SetCooldownProgress(progress);
			}
		}
	}
}

void CardComponent::ForceStateUpdate() {
	if (auto display = GetCardDisplayComponent()) {
		// ���������ȴ��ֻ������ȴ���ȣ����ı�״̬
		if (mIsCooldown) {
			float progress = 1.0f - (mCooldownTimer / mCooldownTime);
			display->SetCooldownProgress(progress);
		}
		else {
			// ������ȴ״̬ʱ���Ÿ���������������״̬
			if (GetCardSlotManager()->CanAfford(mSunCost)) {
				display->TranToReady();
			}
			else {
				display->TranToWaitingSun();
			}
		}
	}
}

void CardComponent::StartCooldown() {
	if (IsReady() && !mIsCooldown) {
		mIsCooldown = true;
		mCooldownTimer = mCooldownTime;

		// ֪ͨ��ʾ�����ʼ��ȴ
		if (auto display = GetCardDisplayComponent()) {
			display->TranToCooling();
		}
	}
}

void CardComponent::SetSelected(bool selected) {
	mIsSelected = selected;

	// ֪ͨ��ʾ���ѡ��״̬�仯
	if (auto display = GetCardDisplayComponent()) {
		display->SetSelected(selected);
		if (selected) {
			display->TranToClick();
		}
		else {
			// ����ʵ��״̬�ָ�
			if (IsReady()) {
				display->TranToReady();
			}
			else if (mIsCooldown) {
				display->TranToCooling();
			}
			else {
				display->TranToWaitingSun();
			}
		}
	}
}

float CardComponent::GetCooldownProgress() const {
	if (!mIsCooldown) return 1.0f;
	return 1.0f - (mCooldownTimer / mCooldownTime);
}

CardState CardComponent::GetCardState() const {
	if (auto display = GetCardDisplayComponent()) {
		return display->GetCardState();
	}
	return CardState::Cooling; // Ĭ�Ϸ�����ȴ״̬
}

std::shared_ptr<CardSlotManager> CardComponent::FindCardSlotManager() const {
	// �ڳ����в���CardSlotManager
	auto& manager = GameObjectManager::GetInstance();
	auto allObjects = manager.GetAllGameObjects();

	for (size_t i = 0; i < allObjects.size(); i++)
	{
		if (auto gameObj = allObjects[i])
		{
			if (auto cardManager = gameObj->GetComponent<CardSlotManager>())
			{
				return cardManager;
			}
		}
	}

	std::cerr << "Warning: No CardSlotManager found in scene!" << std::endl;
	return nullptr;
}

std::shared_ptr<CardSlotManager> CardComponent::GetCardSlotManager() const {
	if (auto manager = mCardSlotManager.lock()) {
		return manager;
	}
	// ��� weak_ptr ��ʧЧ�����²���
	std::cerr << "Warning: CardSlotManager weak_ptr expired, re-finding..." << std::endl;
	auto manager = FindCardSlotManager();
	if (manager) {
		this->mCardSlotManager = manager;
	}
	return manager;
}

std::shared_ptr<CardDisplayComponent> CardComponent::GetCardDisplayComponent() const {
	if (auto display = mCardDisplayComponent.lock()) {
		return display;
	}
	// ��� weak_ptr ��ʧЧ�����»�ȡ
	if (auto gameObject = GetGameObject()) {
		if (auto display = gameObject->GetComponent<CardDisplayComponent>()) {
			this->mCardDisplayComponent = display;
			return display;
		}
	}
	return nullptr;
}