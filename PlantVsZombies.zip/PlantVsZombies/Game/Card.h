#pragma once
#ifndef _CARD_H
#define _CARD_H

#include "GameObject.h"
#include "CardComponent.h"
#include "./Plant/PlantType.h"
#include "ClickableComponent.h"
#include "TransformComponent.h"

constexpr float CARD_SCALE = 0.55f; // �������ű���
constexpr int CARD_WIDTH = static_cast<int>(100 * CARD_SCALE); // ����
constexpr int CARD_HEIGHT = static_cast<int>(140 * CARD_SCALE); // �߶�


class Card : public GameObject {
public:
    Card(PlantType plantType, int sunCost, float cooldown, bool isInChooseCardUI = false);

    // ��ݷ���
    std::shared_ptr<CardComponent> GetCardComponent() { return GetComponent<CardComponent>(); }
    std::shared_ptr<TransformComponent> GetTransform() { return mTransform.lock(); }
    std::shared_ptr<CardDisplayComponent> GetDisplay() { return GetComponent<CardDisplayComponent>(); }
	bool GetIsInChooseCardUI() const { return mIsInChooseCardUI; }
	void SetIsInChooseCardUI(bool isInChooseCardUI) { mIsInChooseCardUI = isInChooseCardUI; }

    void SetOriginalPosition(const Vector& pos) { m_originalPos = pos; }
    Vector GetOriginalPosition() const { return m_originalPos; }

    void SetTargetPosition(const Vector& target);
    bool IsMoving() const { return m_isMoving; }

    void Update() override;

private:
	std::weak_ptr<TransformComponent> mTransform;
    bool mIsInChooseCardUI = false;     // �Ƿ�����ѡ�������еĿ���

    Vector m_originalPos;      // ԭʼλ�ã���ѡ�������еĹ̶�λ�ã�
    Vector m_targetPos;        // Ŀ��λ�ã����ڶ�����
    bool m_isMoving = false;
    float m_moveSpeed = 600.0f; // �ƶ��ٶ�

    void SetupComponents(PlantType plantType, int sunCost, float cooldown);
};

#endif