#include "CardDisplayComponent.h"
#include "../ResourceKeys.h"
#include "./Card.h"
#include "./CardComponent.h"
#include "GameObject.h"
#include "GameObjectManager.h"
#include "./TransformComponent.h"
#include "../DeltaTime.h"
#include "../ResourceManager.h"
#include "../GameApp.h"
#include "./CardSlotManager.h"
#include "./Plant/GameDataManager.h"
#include <iostream>

CardDisplayComponent::CardDisplayComponent(PlantType type, int sunCost, float cooldown)
    : plantType(type), needSun(sunCost), cooldownTime(cooldown) {
    cardState = CardState::Ready;
    showMask = false;
    maskFillAmount = 0.0f;
    currentCooldown = cooldownTime; // ����Ϊ����ȴ����ʾ����Ҫ��ȴ
}

void CardDisplayComponent::Start() {
    LoadTextures();
}

void CardDisplayComponent::Update() {
    if (GetCardComponent()->GetIsInChooseCardUI()) return;

    // ������ȴ��ʱ
    if (cardState == CardState::Cooling) {
        currentCooldown += DeltaTime::GetDeltaTime();
        if (currentCooldown > cooldownTime) {
            currentCooldown = cooldownTime;
        }
    }

    // ����״̬
    UpdateCardState();
}

void CardDisplayComponent::Draw(SDL_Renderer* renderer) {
    if (!GetGameObject() || !GetGameObject()->IsActive()) return;
    auto transfrom = GetTransformComponent();
	if (!transfrom) return;

    DrawCardBackground(renderer, transfrom);
    DrawPlantImage(renderer, transfrom);

    if (showMask && maskFillAmount > 0 || 
        !GetCardComponent()->GetIsInChooseCardUI()) {
        DrawCooldownMask(renderer, transfrom);
    }

    DrawSunCost(renderer, transfrom);

    if (isSelected) {
        DrawSelectionHighlight(renderer, transfrom);
    }
}

void CardDisplayComponent::LoadTextures() {
    auto& resourceManager = ResourceManager::GetInstance();

    // ���ؿ��Ʊ�������
    cardBackground = resourceManager.GetTexture(ResourceKeys::Textures::IMAGE_CARD_BK);
    cardNormal = resourceManager.GetTexture(ResourceKeys::Textures::IMAGE_SEEDPACKETNORMAL);

    // ����ֲ������
    std::string plantKey = GetPlantTextureKey();
    plantTexture = resourceManager.GetTexture(plantKey);

    if (!cardBackground) {
        std::cerr << "Failed to load card background texture" << std::endl;
    }
    if (!cardNormal) {
        std::cerr << "Failed to load card normal texture" << std::endl;
    }
    if (!plantTexture) {
        std::cerr << "Failed to load plant texture: " << plantKey << std::endl;
    }
}

void CardDisplayComponent::DrawCardBackground(SDL_Renderer* renderer, std::shared_ptr<TransformComponent> transform) {
    if (!GetGameObject()) return;

    Vector position = transform->GetPosition();
    SDL_Rect cardRect = {
        static_cast<int>(position.x),
        static_cast<int>(position.y),
        CARD_WIDTH,  // ���ƿ���
        CARD_HEIGHT   // ���Ƹ߶�
    };

    // ���ƿ��Ʊ���
    if (cardNormal) {
        // ����״̬����������������ɫ
        SDL_Color color = GetCurrentColor();
        SDL_SetTextureColorMod(cardNormal, color.r, color.g, color.b);
        SDL_RenderCopy(renderer, cardNormal, nullptr, &cardRect);
        // ����������ɫ
        SDL_SetTextureColorMod(cardNormal, 255, 255, 255);
    }
}

void CardDisplayComponent::DrawPlantImage(SDL_Renderer* renderer, std::shared_ptr<TransformComponent> transform) {
    if (!GetGameObject() || !plantTexture) return;

    Vector position = transform->GetPosition();

    int imgWidth, imgHeight;
    SDL_QueryTexture(plantTexture, nullptr , nullptr, &imgWidth, &imgHeight);

    // ֲ��ͼƬλ�ã��ڿ������룩
    SDL_FRect plantRect = {
        position.x - 14,
        position.y - 10,
        imgWidth * 0.7f, 
        imgHeight * 0.7f
    };

    // ������ɫ���ƣ�����״̬�ı���ɫ��
    SDL_Color color = GetCurrentColor();
    SDL_SetTextureColorMod(plantTexture, color.r, color.g, color.b);
    SDL_SetTextureAlphaMod(plantTexture, 255);

    SDL_RenderCopyF(renderer, plantTexture, nullptr, &plantRect);

    // ������ɫ����
    SDL_SetTextureColorMod(plantTexture, 255, 255, 255);
    SDL_SetTextureAlphaMod(plantTexture, 255);
}

void CardDisplayComponent::DrawCooldownMask(SDL_Renderer* renderer, std::shared_ptr<TransformComponent> transform) {
    if (!GetGameObject() || !cardBackground) return;


    Vector position = transform->GetPosition();

    SDL_Rect cardRect = {
        static_cast<int>(position.x),
        static_cast<int>(position.y),
        CARD_WIDTH,  // ���ƿ���
        CARD_HEIGHT   // ���Ƹ߶�
    };

    // �������ָ߶�  - ���������𽥼���
    // maskFillAmount ��ʾʣ����ȴ�ı��� (1.0 = ��ȫ��ȴ, 0.0 = ��ȴ���)
    int maskHeight = static_cast<int>(cardRect.h * maskFillAmount);
    SDL_Rect maskRect = {
        cardRect.x,
        cardRect.y, // �Ӷ�����ʼ
        cardRect.w,
        maskHeight  // �߶��𽥼���
    };

    // ���浱ǰ�Ļ��ģʽ
    SDL_BlendMode oldBlendMode;
    SDL_GetRenderDrawBlendMode(renderer, &oldBlendMode);

    // ���û��ģʽΪ��ϣ�SDL_BLENDMODE_BLEND��
    SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);

    // ���ư�͸����ɫ������Ϊ����
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 64);
    SDL_RenderFillRect(renderer, &maskRect);

    // �ָ�֮ǰ�Ļ��ģʽ
    SDL_SetRenderDrawBlendMode(renderer, oldBlendMode);

}

void CardDisplayComponent::DrawSunCost(SDL_Renderer* renderer, std::shared_ptr<TransformComponent> transform) {
    if (!GetGameObject()) return;

    Vector position = transform->GetPosition();

    GameAPP::GetInstance().DrawText(std::to_string(needSun),
        Vector(position.x + 6, position.y + 58),
        { 0, 0, 0, 255 },
        ResourceKeys::Fonts::FONT_FZCQ,
        14);
}

void CardDisplayComponent::DrawSelectionHighlight(SDL_Renderer* renderer, std::shared_ptr<TransformComponent> transform) {
    if (!GetGameObject()) return;

    Vector position = transform->GetPosition();

    // ����ѡ�и����߿�
    SDL_Rect highlightRect = {
        static_cast<int>(position.x),
        static_cast<int>(position.y),
        CARD_WIDTH,  // ���ƿ���
        CARD_HEIGHT   // ���Ƹ߶�
    };

    SDL_BlendMode oldBlendMode;
    SDL_GetRenderDrawBlendMode(renderer, &oldBlendMode);

    // ���û��ģʽΪ��ϣ�SDL_BLENDMODE_BLEND��
    SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);

    // ���ư�͸����ɫ������Ϊ����
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 64);
    SDL_RenderFillRect(renderer, &highlightRect);

    // �ָ�֮ǰ�Ļ��ģʽ
    SDL_SetRenderDrawBlendMode(renderer, oldBlendMode);
}

void CardDisplayComponent::UpdateCardState() {
    // ��ȡ�����߼����
    auto cardComp = GetCardComponent();
    if (!cardComp) return;
    // ��ȡ���۹�����
    auto cardSlotManager = cardComp->GetCardSlotManager();
    if (!cardSlotManager) return;

    // ���������ȴ��ֻ������ȴ���ȣ�������״̬ת��
    if (cardState == CardState::Cooling) {
        // ������ȴ����
        if (cardComp->IsCooldown()) {
            float progress = 1.0f - (cardComp->GetCooldownProgress());
            maskFillAmount = progress;
        }
        else {
            // ��ȴ������������������ת��״̬
            if (cardSlotManager->CanAfford(needSun)) {
                TranToReady();
            }
            else {
                TranToWaitingSun();
            }
        }
        return;
    }

    // ��ȡ��ǰ��������
    int currentSun = cardSlotManager->GetCurrentSun();

    // ������������״̬��ֻ��������ȴ״̬��
    switch (cardState) {
    case CardState::Ready:
        // ����״̬����������Ƿ���
        if (currentSun < needSun) {
            TranToWaitingSun();
        }
        break;

    case CardState::WaitingSun:
        // �ȴ�����״̬����������Ƿ��㹻
        if (currentSun >= needSun) {
            TranToReady();
        }
        break;

    case CardState::Click:
        break;
    }
}

void CardDisplayComponent::UpdateCooldown(float deltaTime) {
    if (currentCooldown < cooldownTime) {
        currentCooldown += deltaTime;
        maskFillAmount = 1.0f - (currentCooldown / cooldownTime);

        if (currentCooldown >= cooldownTime) {
            TranToWaitingSun(); // ��ȴ������תΪ�ȴ�����״̬
        }
    }
}

void CardDisplayComponent::TranToWaitingSun() {
    cardState = CardState::WaitingSun;
    showMask = true;
    maskFillAmount = 1.0f;
    currentCooldown = cooldownTime; // ȷ����ȴ���
}

void CardDisplayComponent::TranToReady() {
    if (isSelected)
    {
		return; 
    }
    cardState = CardState::Ready;
    showMask = false;
    maskFillAmount = 0.0f;
    currentCooldown = cooldownTime; // ������ȴ
}

void CardDisplayComponent::TranToCooling() {
    cardState = CardState::Cooling;
    showMask = true;
    maskFillAmount = 1.0f;
    currentCooldown = 0.0f;
}

void CardDisplayComponent::TranToClick() {
    cardState = CardState::Click;
    showMask = false;
}

SDL_Color CardDisplayComponent::GetCurrentColor() const {
    switch (cardState) {
    case CardState::Ready:
        return readyColor;
    case CardState::Cooling:
        return disabledColor;
    case CardState::WaitingSun:
        return waitingSunColor;
    case CardState::Click:
        return clickColor;
    default:
        return readyColor;
    }
}

std::shared_ptr<CardComponent> CardDisplayComponent::GetCardComponent() const {
    if (auto cardComp = mCardComponent.lock()) {
        return cardComp;
    }
    // ��� weak_ptr ��ʧЧ�����²���
    if (auto gameObject = GetGameObject()) {
        auto cardComp = gameObject->GetComponent<CardComponent>();
        if (cardComp) {
            this->mCardComponent = cardComp;
        }
        return cardComp;
    }
    return nullptr;
}

std::shared_ptr<TransformComponent> CardDisplayComponent::GetTransformComponent() const {
    if (auto transformComp = mTransformComponent.lock()) {
        return transformComp;
    }

    if (auto gameObject = GetGameObject()) {
        auto transformComp = gameObject->GetComponent<TransformComponent>();
        if (transformComp) {
            this->mTransformComponent = transformComp;
        }
        return transformComp;
    }
    return nullptr;
}

std::string CardDisplayComponent::GetPlantTextureKey() const {
    return GameDataManager::GetInstance().GetPlantTextureKey(plantType);
}