#pragma once
#ifndef _GAME_MONITOR_H
#define _GAME_MONITOR_H
#include "CrashHandler.h"

struct StackUsageInfo {
	ULONG_PTR stackLow;
	ULONG_PTR stackHigh;
	SIZE_T totalReserved;
	SIZE_T used;
	SIZE_T remaining;
	double usagePercent;
};

struct MemoryStatus {
    SIZE_T totalPhysical;
    SIZE_T availablePhysical;
    SIZE_T totalPageFile;
    SIZE_T availablePageFile;
    SIZE_T totalVirtual;
    SIZE_T availableVirtual;
    SIZE_T processMemoryUsage;
    SIZE_T peakProcessMemory;
    DWORD memoryLoad; // �ڴ�ʹ�ðٷֱ� 0-100
};

struct ProcessInfo {
    DWORD processId;
    DWORD threadCount;
    DWORD handleCount;
    SIZE_T workingSetSize;
    SIZE_T pagefileUsage;
    std::string executablePath;
};

struct PerformanceMetrics {
    double frameRate;
    double frameTime;
    ULONGLONG totalFrames;
    ULONGLONG lastUpdateTime;
};

class GameMonitor {
private:
    static PerformanceMetrics performance;
    static ULONGLONG frameCount;
    static ULONGLONG lastFrameTime;

public:
	// ��ӡ��ջ���
	static void PrintStackUsage();
	// ��ȡ��ջ���
	static StackUsageInfo GetStackUsage();
    // �Ѽ��
    static void PrintHeapUsage();
    static SIZE_T GetProcessHeapUsage();
    static SIZE_T GetPrivateBytes();

    // ϵͳ�ڴ���
    static void PrintSystemMemoryStatus();
    static MemoryStatus GetSystemMemoryStatus();

    // ������Ϣ
    static void PrintProcessInfo();
    static ProcessInfo GetProcessInfo();

    // ���ܼ��
    static void UpdateFrame();
    static void PrintPerformanceMetrics();
    static PerformanceMetrics GetPerformanceMetrics();

    // ����ϵͳ����
    static void PrintComprehensiveReport();

    // �̼߳��
    static DWORD GetThreadCount();
    static void PrintThreadInfo();

    // ģ����
    static void PrintLoadedModules();

    // ��Դй©���
    static void CheckResourceLeaks();

    // ��ؾ���
    static void CheckSystemHealth();
};

#endif