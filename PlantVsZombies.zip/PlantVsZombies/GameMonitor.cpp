#include "GameMonitor.h"
#include <iostream>
#include <sstream>
#include <iomanip>
#include <psapi.h>
#include <tlhelp32.h>

#pragma comment(lib, "psapi.lib")

// ��ʼ����̬��Ա
PerformanceMetrics GameMonitor::performance = { 0 };
ULONGLONG GameMonitor::frameCount = 0;
ULONGLONG GameMonitor::lastFrameTime = 0;

void GameMonitor::PrintStackUsage() {
	StackUsageInfo usage = GetStackUsage();
	std::cout << "=== ջʹ����� ===" << std::endl;
	std::cout << "�ܱ�����С: " << usage.totalReserved / 1024 << " KB" << std::endl;
	std::cout << "��ʹ��: " << usage.used / 1024 << " KB" << std::endl;
	std::cout << "ʣ��: " << usage.remaining / 1024 << " KB" << std::endl;
	std::cout << "ʹ����: " << std::fixed << std::setprecision(2) << usage.usagePercent << "%" << std::endl;

	if (usage.usagePercent > 80.0) {
		std::cout << "  ����: ջʹ���ʽϸ�!" << std::endl;
	}
}

StackUsageInfo GameMonitor::GetStackUsage() {
	StackUsageInfo info = { 0 };
	ULONG_PTR stackLow, stackHigh;
	ULONG_PTR currentStack = (ULONG_PTR)_AddressOfReturnAddress();
	GetCurrentThreadStackLimits(&stackLow, &stackHigh);
	info.totalReserved = stackHigh - stackLow;
	info.remaining = currentStack - stackLow;
	info.used = info.totalReserved - info.remaining;
	info.usagePercent = (info.totalReserved > 0) ?
		(double)info.used / info.totalReserved * 100.0 : 0.0;
	info.stackLow = stackLow;
	info.stackHigh = stackHigh;

	return info;
}

void GameMonitor::PrintHeapUsage() {
	SIZE_T heapUsage = GetProcessHeapUsage();
	SIZE_T privateBytes = GetPrivateBytes();

	std::cout << "=== ���ڴ�ʹ����� ===" << std::endl;
	std::cout << "���̶�ʹ��: " << heapUsage / 1024 << " KB" << std::endl;
	std::cout << "˽���ֽ���: " << privateBytes / 1024 << " KB" << std::endl;

	// ��ȫ�ػ�ȡĬ�϶���Ϣ
	HANDLE defaultHeap = GetProcessHeap();
	if (defaultHeap) {
		// ʹ�ø���ȫ�ķ�����ȡ����Ϣ
		HEAP_SUMMARY heapSummary = { 0 };
		heapSummary.cb = sizeof(HEAP_SUMMARY);

		// ����ʹ��HeapSummary������ȫ�ķ�����
		if (HeapSummary(defaultHeap, 0, &heapSummary)) {
			std::cout << "Ĭ�϶� - �ύ��С: " << heapSummary.cbCommitted / 1024 << " KB" << std::endl;
			std::cout << "Ĭ�϶� - ������С: " << heapSummary.cbReserved / 1024 << " KB" << std::endl;
			std::cout << "Ĭ�϶� - �ѷ����: " << heapSummary.cbAllocated << std::endl;
		}
		else {
			// ���÷�����ʹ��HeapLock/HeapWalk��������ȫ
			if (HeapLock(defaultHeap)) {
				PROCESS_HEAP_ENTRY entry = { 0 };
				SIZE_T totalHeapSize = 0;
				SIZE_T usedHeapSize = 0;
				DWORD entryCount = 0;
				const DWORD maxEntries = 10000; // ��ֹ����ѭ��

				// ��ȫ�ر�����
				while (HeapWalk(defaultHeap, &entry) && entryCount < maxEntries) {
					entryCount++;
					totalHeapSize += entry.cbData;
					if (entry.wFlags & PROCESS_HEAP_ENTRY_BUSY) {
						usedHeapSize += entry.cbData;
					}

					// ����entry.cbData�Է�ֹǱ������
					entry.cbData = 0;
				}

				HeapUnlock(defaultHeap);

				std::cout << "Ĭ�϶� - �ܴ�С: " << totalHeapSize / 1024 << " KB" << std::endl;
				std::cout << "Ĭ�϶� - ��ʹ��: " << usedHeapSize / 1024 << " KB" << std::endl;
				std::cout << "ɨ��Ķѿ�����: " << entryCount << std::endl;
			}
			else {
				std::cout << "�޷������ѽ��м��" << std::endl;
			}
		}
	}
}

SIZE_T GameMonitor::GetProcessHeapUsage() {
	SIZE_T totalHeapSize = 0;

	// ��ȫ�ػ�ȡ������
	DWORD numberOfHeaps = GetProcessHeaps(0, nullptr);
	if (numberOfHeaps > 0) {
		HANDLE* heaps = new (std::nothrow) HANDLE[numberOfHeaps];
		if (heaps) {
			DWORD actualHeaps = GetProcessHeaps(numberOfHeaps, heaps);

			for (DWORD i = 0; i < actualHeaps; i++) {
				// ʹ��HeapSummary���HeapWalk������ȫ
				HEAP_SUMMARY summary = { 0 };
				summary.cb = sizeof(HEAP_SUMMARY);

				if (HeapSummary(heaps[i], 0, &summary)) {
					totalHeapSize += summary.cbCommitted;
				}
				else {
					// ���÷�������ȫ��ʹ��HeapLock/HeapWalk
					if (HeapLock(heaps[i])) {
						PROCESS_HEAP_ENTRY entry = { 0 };
						SIZE_T heapSize = 0;
						DWORD entryCount = 0;
						const DWORD maxEntries = 5000;

						while (HeapWalk(heaps[i], &entry) && entryCount < maxEntries) {
							entryCount++;
							if (entry.wFlags & PROCESS_HEAP_ENTRY_BUSY) {
								heapSize += entry.cbData;
							}
							entry.cbData = 0; // ����
						}

						HeapUnlock(heaps[i]);
						totalHeapSize += heapSize;
					}
				}
			}

			delete[] heaps;
		}
	}

	return totalHeapSize;
}

SIZE_T GameMonitor::GetPrivateBytes() {
	PROCESS_MEMORY_COUNTERS_EX pmc;
	if (GetProcessMemoryInfo(GetCurrentProcess(),
		(PROCESS_MEMORY_COUNTERS*)&pmc,
		sizeof(pmc))) {
		return pmc.PrivateUsage;
	}
	return 0;
}

void GameMonitor::PrintSystemMemoryStatus() {
	MemoryStatus status = GetSystemMemoryStatus();

	std::cout << "=== ϵͳ�ڴ�״̬ ===" << std::endl;
	std::cout << "�ڴ渺��: " << status.memoryLoad << "%" << std::endl;
	std::cout << "�����ڴ� - ����: " << status.totalPhysical / (1024 * 1024) << " MB" << std::endl;
	std::cout << "�����ڴ� - ����: " << status.availablePhysical / (1024 * 1024) << " MB" << std::endl;
	std::cout << "ҳ���ļ� - ����: " << status.totalPageFile / (1024 * 1024) << " MB" << std::endl;
	std::cout << "ҳ���ļ� - ����: " << status.availablePageFile / (1024 * 1024) << " MB" << std::endl;
	std::cout << "�����ڴ� - ����: " << status.totalVirtual / (1024 * 1024) << " MB" << std::endl;
	std::cout << "�����ڴ� - ����: " << status.availableVirtual / (1024 * 1024) << " MB" << std::endl;

	if (status.memoryLoad > 85) {
		std::cout << "����: ϵͳ�ڴ�ʹ���ʹ���!" << std::endl;
	}
}

MemoryStatus GameMonitor::GetSystemMemoryStatus() {
	MemoryStatus status = { 0 };

	// ϵͳ�ڴ�״̬
	MEMORYSTATUSEX memStatus;
	memStatus.dwLength = sizeof(memStatus);
	if (GlobalMemoryStatusEx(&memStatus)) {
		status.totalPhysical = memStatus.ullTotalPhys;
		status.availablePhysical = memStatus.ullAvailPhys;
		status.totalPageFile = memStatus.ullTotalPageFile;
		status.availablePageFile = memStatus.ullAvailPageFile;
		status.totalVirtual = memStatus.ullTotalVirtual;
		status.availableVirtual = memStatus.ullAvailVirtual;
		status.memoryLoad = memStatus.dwMemoryLoad;
	}

	// �����ڴ�ʹ��
	PROCESS_MEMORY_COUNTERS_EX pmc;
	if (GetProcessMemoryInfo(GetCurrentProcess(),
		(PROCESS_MEMORY_COUNTERS*)&pmc,
		sizeof(pmc))) {
		status.processMemoryUsage = pmc.WorkingSetSize;
		status.peakProcessMemory = pmc.PeakWorkingSetSize;
	}

	return status;
}

void GameMonitor::PrintProcessInfo() {
	ProcessInfo info = GetProcessInfo();

	std::cout << "=== ������Ϣ ===" << std::endl;
	std::cout << "����ID: " << info.processId << std::endl;
	std::cout << "�߳�����: " << info.threadCount << std::endl;
	std::cout << "�������: " << info.handleCount << std::endl;
	std::cout << "��������С: " << info.workingSetSize / 1024 << " KB" << std::endl;
	std::cout << "ҳ���ļ�ʹ��: " << info.pagefileUsage / 1024 << " KB" << std::endl;
	std::cout << "ִ���ļ�·��: " << info.executablePath << std::endl;
}

ProcessInfo GameMonitor::GetProcessInfo() {
	ProcessInfo info = { 0 };
	info.processId = GetCurrentProcessId();

	// ��ȡ�߳�����
	info.threadCount = GetThreadCount();

	// ��ȡ�������
	info.handleCount = 0;
	HANDLE hProcess = GetCurrentProcess();
	if (GetProcessHandleCount(hProcess, &info.handleCount) == FALSE) {
		info.handleCount = 0;
	}

	// ��ȡ�ڴ���Ϣ
	PROCESS_MEMORY_COUNTERS_EX pmc;
	if (GetProcessMemoryInfo(hProcess, (PROCESS_MEMORY_COUNTERS*)&pmc, sizeof(pmc))) {
		info.workingSetSize = pmc.WorkingSetSize;
		info.pagefileUsage = pmc.PagefileUsage;
	}

	// ��ȡִ���ļ�·��
	char exePath[MAX_PATH];
	if (GetModuleFileNameA(nullptr, exePath, MAX_PATH)) {
		info.executablePath = exePath;
	}

	return info;
}

void GameMonitor::UpdateFrame() {
	ULONGLONG currentTime = GetTickCount64();
	frameCount++;

	// ÿ�����һ������ָ��
	if (currentTime - performance.lastUpdateTime >= 1000) {
		ULONGLONG elapsed = currentTime - performance.lastUpdateTime;
		performance.frameRate = (frameCount - performance.totalFrames) * 1000.0 / elapsed;
		performance.frameTime = 1000.0 / performance.frameRate;
		performance.totalFrames = frameCount;
		performance.lastUpdateTime = currentTime;
	}
}

void GameMonitor::PrintPerformanceMetrics() {
	std::cout << "=== ����ָ�� ===" << std::endl;
	std::cout << "֡��: " << std::fixed << std::setprecision(2) << performance.frameRate << " FPS" << std::endl;
	std::cout << "֡ʱ��: " << std::fixed << std::setprecision(2) << performance.frameTime << " ms" << std::endl;
	std::cout << "��֡��: " << performance.totalFrames << std::endl;

	if (performance.frameRate < 30.0) {
		std::cout << "  ����: ֡�ʹ���!" << std::endl;
	}
}

PerformanceMetrics GameMonitor::GetPerformanceMetrics() {
	return performance;
}

DWORD GameMonitor::GetThreadCount() {
	DWORD threadCount = 0;
	HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);

	if (hSnapshot != INVALID_HANDLE_VALUE) {
		THREADENTRY32 te32;
		te32.dwSize = sizeof(THREADENTRY32);

		DWORD currentProcessId = GetCurrentProcessId();

		if (Thread32First(hSnapshot, &te32)) {
			do {
				if (te32.th32OwnerProcessID == currentProcessId) {
					threadCount++;
				}
			} while (Thread32Next(hSnapshot, &te32));
		}

		CloseHandle(hSnapshot);
	}

	return threadCount;
}

void GameMonitor::PrintThreadInfo() {
	DWORD threadCount = GetThreadCount();
	std::cout << "=== �߳���Ϣ ===" << std::endl;
	std::cout << "�߳�����: " << threadCount << std::endl;
}

void GameMonitor::PrintLoadedModules() {
	std::cout << "=== �Ѽ���ģ�� ===" << std::endl;

	HMODULE hModules[1024];
	DWORD cbNeeded;

	if (EnumProcessModules(GetCurrentProcess(), hModules, sizeof(hModules), &cbNeeded)) {
		for (DWORD i = 0; i < (cbNeeded / sizeof(HMODULE)); i++) {
			char szModName[MAX_PATH];
			if (GetModuleFileNameExA(GetCurrentProcess(), hModules[i], szModName, sizeof(szModName))) {
				std::cout << "ģ�� " << i << ": " << szModName << std::endl;
			}
		}
	}
}

void GameMonitor::CheckResourceLeaks() {
	std::cout << "=== ��Դй©��� ===" << std::endl;

	// ���GDI����й©
	int gdiObjects = GetGuiResources(GetCurrentProcess(), GR_GDIOBJECTS);
	int userObjects = GetGuiResources(GetCurrentProcess(), GR_USEROBJECTS);

	std::cout << "GDI����: " << gdiObjects << std::endl;
	std::cout << "�û�����: " << userObjects << std::endl;

	if (gdiObjects > 1000) {
		std::cout << "����: GDI�����������࣬���ܴ���й©!" << std::endl;
	}

	if (userObjects > 1000) {
		std::cout << "����: �û������������࣬���ܴ���й©!" << std::endl;
	}
}

void GameMonitor::CheckSystemHealth() {
	std::cout << "=== ϵͳ������� ===" << std::endl;

	StackUsageInfo stackInfo = GetStackUsage();
	MemoryStatus memStatus = GetSystemMemoryStatus();

	bool isHealthy = true;

	if (stackInfo.usagePercent > 80.0) {
		std::cout << "ջʹ���ʹ���: " << stackInfo.usagePercent << "%" << std::endl;
		isHealthy = false;
	}

	if (memStatus.memoryLoad > 85) {
		std::cout << "ϵͳ�ڴ渺�ع���: " << memStatus.memoryLoad << "%" << std::endl;
		isHealthy = false;
	}

	if (performance.frameRate < 30.0 && performance.totalFrames > 100) {
		std::cout << "֡�ʹ���: " << performance.frameRate << " FPS" << std::endl;
		isHealthy = false;
	}

	SIZE_T privateBytes = GetPrivateBytes();
	if (privateBytes > 500 * 1024 * 1024) { // 500MB
		std::cout << "�����ڴ�ʹ�ù���: " << privateBytes / (1024 * 1024) << " MB" << std::endl;
		isHealthy = false;
	}

	if (isHealthy) {
		std::cout << "ϵͳ״̬����" << std::endl;
	}
	else {
		std::cout << "����ϵͳ�������⣬����!" << std::endl;
	}
}

void GameMonitor::PrintComprehensiveReport() {
	std::cout << "\n" << std::string(60, '=') << std::endl;
	std::cout << "��Ϸ����ۺϱ���" << std::endl;
	std::cout << std::string(60, '=') << std::endl;

	PrintStackUsage();
	std::cout << std::endl;

	PrintHeapUsage();
	std::cout << std::endl;

	PrintSystemMemoryStatus();
	std::cout << std::endl;

	PrintProcessInfo();
	std::cout << std::endl;

	PrintPerformanceMetrics();
	std::cout << std::endl;

	PrintThreadInfo();
	std::cout << std::endl;

	CheckResourceLeaks();
	std::cout << std::endl;

	CheckSystemHealth();
	std::cout << std::string(60, '=') << std::endl;
}