#include "ResourceManager.h"
#include "./Game/Plant/GameDataManager.h"
#include <algorithm>

ResourceManager* ResourceManager::instance = nullptr;

ResourceManager& ResourceManager::GetInstance()
{
    if (!instance)
    {
        instance = new ResourceManager();
    }
    return *instance;
}

void ResourceManager::ReleaseInstance()
{
    if (instance)
    {
        instance->UnloadAll();
        delete instance;
        instance = nullptr;
    }
}

bool ResourceManager::Initialize(SDL_Renderer* renderer, const std::string& configPath)
{
    this->renderer = renderer;

    if (!configReader.LoadConfig(configPath)) {
        std::cerr << "Failed to load resource configuration from: " << configPath << std::endl;
        return false;
    }

    return true;
}

bool ResourceManager::LoadAllGameImages() {
    bool success = true;
#ifdef _DEBUG
    std::cout << "��ʼ������ϷͼƬ��Դ..." << std::endl;
#endif
    const auto& infos = GetGameImageInfos();
    for (const auto& info : infos) {
        if (!LoadTiledTexture(info, "IMAGE_")) {
            std::cerr << "������ϷͼƬʧ��: " << info.path << std::endl;
            success = false;
        }
    }
#ifdef _DEBUG
    std::cout << "��ϷͼƬ��Դ������ɣ��ɹ�: "
        << textures.size() << "/" << infos.size() << std::endl;
#endif
    return success;
}

bool ResourceManager::LoadAllParticleTextures() {
    bool success = true;
#ifdef _DEBUG
    std::cout << "��ʼ������������..." << std::endl;
#endif
    const auto& infos = GetParticleTextureInfos();
    for (const auto& info : infos) {
        if (!LoadTiledTexture(info, "PARTICLE_")) {
            std::cerr << "������������ʧ��: " << info.path << std::endl;
            success = false;
        }
    }
#ifdef _DEBUG
    std::cout << "���������������" << std::endl;
#endif
    return success;
}

bool ResourceManager::LoadFont(const std::string& path, const std::string& key)
{
    std::string actualKey = key.empty() ? path : key;

    // ����Ƿ��Ѽ���
    if (fonts.find(actualKey) != fonts.end())
    {
        return true; // �����Ѽ���
    }

    // ��ʼ���յ������Сӳ��
    fonts[actualKey] = std::unordered_map<int, TTF_Font*>();
#ifdef _DEBUG
    std::cout << "ע������: " << path << " (key: " << actualKey << ")" << std::endl;
#endif
    return true;
}

// ��ȡ����С����
TTF_Font* ResourceManager::GetFont(const std::string& key, int size)
{
    if (key.empty() || size <= 0)
    {
        std::cerr << "��Ч���������: key=" << key << ", size=" << size << std::endl;
        return nullptr;
    }

    auto fontIt = fonts.find(key);
    if (fontIt == fonts.end())
    {
        std::cerr << "����δע��: '" << key << "'" << std::endl;
        return nullptr;
    }

    // ���ô�С�Ƿ��Ѽ���
    auto& sizeMap = fontIt->second;
    auto sizeIt = sizeMap.find(size);
    if (sizeIt != sizeMap.end())
    {
        return sizeIt->second;
    }
    // �ҵ������ļ�·��
    std::string fontPath;
    const auto& fontPaths = configReader.GetFontPaths();
    for (const auto& path : fontPaths)
    {
        // ��·������ȡ�ļ�����������չ�������бȽ�
        std::string filename = path.substr(path.find_last_of("/\\") + 1);
        std::string fileKey = filename.substr(0, filename.find_last_of('.'));
        if (fileKey == key)
        {
            fontPath = path;
            break;
        }
    }

    if (fontPath.empty())
    {
        // ���û�ҵ�������ʹ������·����Ϊ����
        for (const auto& path : fontPaths)
        {
#ifdef _DEBUG
            std::cout << "��������·��ƥ��: path='" << path << "' with key='" << key << "'" << std::endl;
#endif
            if (path == key) // ֱ�ӱȽ�����·��
            {
                fontPath = path;
                break;
            }
        }
    }

    if (fontPath.empty())
    {
        std::cerr << "����: �Ҳ��������ļ�·�� for key: '" << key << "'" << std::endl;
        std::cout << "���õ�����·��: ";
        for (const auto& path : fontPaths) {
            std::cout << path << " ";
        }
        std::cout << std::endl;
        return nullptr;
    }
    // ��������ض���С������
    TTF_Font* font = TTF_OpenFont(fontPath.c_str(), size);
    if (!font)
    {
        std::cerr << "��������ʧ��: " << fontPath << " size: " << size << " - " << TTF_GetError() << std::endl;
        return nullptr;
    }

    sizeMap[size] = font;
    std::cout << "�ɹ���������: '" << key << "' size: " << size << std::endl;
    return font;
}

bool ResourceManager::LoadAllFonts()
{
    bool success = true;
#ifdef _DEBUG
    std::cout << "��ʼע������..." << std::endl;
#endif
    const auto& paths = configReader.GetFontPaths();
    for (const auto& path : paths)
    {
        if (!LoadFont(path))
        {
            std::cerr << "ע������ʧ��: " << path << std::endl;
            success = false;
        }
    }
#ifdef _DEBUG
    std::cout << "����ע�����" << std::endl;
#endif
    return success;
}

void ResourceManager::UnloadFont(const std::string& key)
{
    auto it = fonts.find(key);
    if (it != fonts.end())
    {
        for (auto& sizePair : it->second)
        {
            TTF_CloseFont(sizePair.second);
        }
        fonts.erase(it);
#ifdef _DEBUG
        std::cout << "ж������: " << key << std::endl;
#endif
    }
}

std::vector<int> ResourceManager::GetLoadedFontSizes(const std::string& key) const
{
    std::vector<int> sizes;
    auto it = fonts.find(key);
    if (it != fonts.end())
    {
        for (const auto& sizePair : it->second)
        {
            sizes.push_back(sizePair.first);
        }
    }
    return sizes;
}

int ResourceManager::GetLoadedFontCount() const
{
    int total = 0;
    for (const auto& fontPair : fonts)
    {
        total += static_cast<int>(fontPair.second.size());
    }
    return total;
}

// ж���ض������С
void ResourceManager::UnloadFontSize(const std::string& key, int size)
{
    auto fontIt = fonts.find(key);
    if (fontIt != fonts.end())
    {
        auto& sizeMap = fontIt->second;
        auto sizeIt = sizeMap.find(size);
        if (sizeIt != sizeMap.end())
        {
            TTF_CloseFont(sizeIt->second);
            sizeMap.erase(sizeIt);
#ifdef _DEBUG
            std::cout << "ж������: " << key << " size: " << size << std::endl;
#endif
            // ����������û��������С�ˣ���ȫ�Ƴ�
            if (sizeMap.empty())
            {
                fonts.erase(fontIt);
            }
        }
    }
}

// ����δʹ�������С
void ResourceManager::CleanupUnusedFontSizes()
{
    int removedCount = 0;
    for (auto it = fonts.begin(); it != fonts.end(); )
    {
        if (it->second.empty())
        {
            it = fonts.erase(it);
            removedCount++;
        }
        else
        {
            ++it;
        }
    }
#ifdef _DEBUG
    std::cout << "������ " << removedCount << " ����������Ŀ" << std::endl;
#endif
}

bool ResourceManager::LoadAllSounds()
{
    bool success = true;
#ifdef _DEBUG
    std::cout << "��ʼ������Ч..." << std::endl;
#endif
    const auto& paths = configReader.GetSoundPaths();
    for (const auto& path : paths)
    {
        std::string key = GenerateStandardKey(path, "SOUND_");
        if (!LoadSound(path, key))
        {
            std::cerr << "������Чʧ��: " << path << std::endl;
            success = false;
        }
    }
#ifdef _DEBUG
    std::cout << "��Ч�������" << std::endl;
#endif
    return success;
}

bool ResourceManager::LoadAllMusic()
{
    bool success = true;
#ifdef _DEBUG
    std::cout << "��ʼ��������..." << std::endl;
#endif
    const auto& paths = configReader.GetMusicPaths();
    for (const auto& path : paths)
    {
        std::string key = GenerateStandardKey(path, "MUSIC_");
        if (!LoadMusic(path, key))
        {
            std::cerr << "��������ʧ��: " << path << std::endl;
            success = false;
        }
    }
#ifdef _DEBUG
    std::cout << "���ּ������" << std::endl;
#endif
    return success;
}

std::shared_ptr<Reanimation> ResourceManager::LoadReanimation(const std::string& key, const std::string& path) {
    // ����Ƿ��Ѽ���
    auto it = mReanimations.find(key);
    if (it != mReanimations.end()) {
        return it->second;
    }

    // �����µ�Reanimation
    auto reanim = std::make_shared<Reanimation>();
    reanim->mResourceManager = this;
    if (!reanim->LoadFromFile(path)) {
        std::cerr << "Failed to load reanimation: " << path << std::endl;
        return nullptr;
    }

    mReanimations[key] = reanim;
#ifdef _DEBUG
    std::cout << "Successfully loaded reanimation: " << key << " from " << path << std::endl;
#endif
    return reanim;
}

std::shared_ptr<Reanimation> ResourceManager::GetReanimation(const std::string& key) {
    auto it = mReanimations.find(key);
    if (it != mReanimations.end()) {
        // �ӻ����ȡ���ݣ��������µĶ���ʵ��
        auto cachedReanim = it->second;
        auto newReanim = std::make_shared<Reanimation>();

        // ���ƻ�������
        newReanim->mFPS = cachedReanim->mFPS;
        newReanim->mIsLoaded = cachedReanim->mIsLoaded;
        newReanim->mResourceManager = cachedReanim->mResourceManager;

        // ����������
        newReanim->mTracks = cachedReanim->mTracks;

        return newReanim;
    }

    std::cerr << "Reanimation not found: " << key << std::endl;
    return nullptr;
}

std::string ResourceManager::AnimationTypeToString(AnimationType type) {
    return GameDataManager::GetInstance().GetAnimationName(type);
}

void ResourceManager::UnloadReanimation(const std::string& key) {
    auto it = mReanimations.find(key);
    if (it != mReanimations.end()) {
        mReanimations.erase(it);
#ifdef _DEBUG
        std::cout << "Unloaded reanimation: " << key << std::endl;
#endif
    }
}

bool ResourceManager::HasReanimation(const std::string& key) const {
    return mReanimations.find(key) != mReanimations.end();
}

bool ResourceManager::LoadAllReanimations()
{
    if (!renderer) {
        std::cerr << "����: ResourceManager δ��ʼ�����޷����ض�����" << std::endl;
        return false;
    }

    bool success = true;
    int loadedCount = 0;
#ifdef _DEBUG
    std::cout << "��ʼ�������ж�����Դ..." << std::endl;
#endif
    const auto& reanimPaths = configReader.GetReanimationPaths();
    for (const auto& reanimPair : reanimPaths) {
        const std::string& key = reanimPair.first;
        const std::string& path = reanimPair.second;

        if (LoadReanimation(key, path)) {
            loadedCount++;
            std::cout << "�ɹ����ض���: " << key << " from " << path << std::endl;
        }
        else {
            success = false;
            std::cerr << "���ض���ʧ��: " << key << " from " << path << std::endl;
        }
    }
#ifdef _DEBUG
    std::cout << "������Դ������ɣ��ɹ�: " << loadedCount << "/" << reanimPaths.size() << std::endl;
#endif
    return success;
}

SDL_Texture* ResourceManager::LoadTexture(const std::string& path, const std::string& key)
{
    if (!renderer)
    {
        std::cerr << "����: ResourceManager δ��ʼ����" << std::endl;
        return nullptr;
    }

    std::string actualKey = key.empty() ? path : key;

    // ����Ƿ��Ѽ���
    if (textures.find(actualKey) != textures.end())
    {
        return textures[actualKey];
    }

    SDL_Texture* texture = IMG_LoadTexture(renderer, path.c_str());
    if (!texture)
    {
        // ���Բ�ͬ��·����ʽ
        std::cerr << "��������ʧ��: " << path << " - " << IMG_GetError() << std::endl;

        // ����ļ��Ƿ����
        SDL_RWops* file = SDL_RWFromFile(path.c_str(), "rb");
        if (!file) {
            std::cerr << "�ļ������ڻ��޷���: " << path << std::endl;
        }
        else {
            SDL_RWclose(file);
        }

        return nullptr;
    }

    // ��ȡ�����ߴ粢��֤
    int width, height;
    if (SDL_QueryTexture(texture, NULL, NULL, &width, &height) != 0) {
        std::cerr << "��ȡ�����ߴ�ʧ��: " << path << " - " << SDL_GetError() << std::endl;
        SDL_DestroyTexture(texture);
        return nullptr;
    }

    if (width <= 0 || height <= 0) {
        std::cerr << "��Ч�������ߴ�: " << width << "x" << height << " for " << path << std::endl;
        SDL_DestroyTexture(texture);
        return nullptr;
    }

    // ������������
    SDL_SetTextureScaleMode(texture, SDL_ScaleModeLinear);
    SDL_SetTextureBlendMode(texture, SDL_BLENDMODE_BLEND);
    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "1");

    textures[actualKey] = texture;

#ifdef _DEBUG
    std::cout << "�ɹ���������: " << path << " (key: " << actualKey << ") �ߴ�: "
        << width << "x" << height << std::endl;
#endif
    return texture;
}

SDL_Texture* ResourceManager::GetTexture(const std::string& key)
{
    auto it = textures.find(key);
    if (it != textures.end())
    {
        return it->second;
    }
    std::cerr << "����: ����δ�ҵ�: " << key << std::endl;
    return nullptr;
}

std::string ResourceManager::GenerateTextureKey(const std::string& path)
{
    std::string filename = path.substr(path.find_last_of("/\\") + 1);
    std::string nameWithoutExt = filename.substr(0, filename.find_last_of('.'));

    // ת��Ϊ��д
    std::transform(nameWithoutExt.begin(), nameWithoutExt.end(), nameWithoutExt.begin(), ::toupper);

    // ������ĸ�����ַ��滻Ϊ�»���
    for (char& c : nameWithoutExt) {
        if (!std::isalnum(c)) {
            c = '_';
        }
    }

    return "IMAGE_" + nameWithoutExt;
}

std::string ResourceManager::GenerateStandardKey(const std::string& path, const std::string& prefix)
{
    std::string filename = path.substr(path.find_last_of("/\\") + 1);
    std::string nameWithoutExt = filename.substr(0, filename.find_last_of('.'));

    // ת��Ϊ��д
    std::transform(nameWithoutExt.begin(), nameWithoutExt.end(), nameWithoutExt.begin(), ::toupper);

    // ������ĸ�����ַ��滻Ϊ�»���
    for (char& c : nameWithoutExt) {
        if (!std::isalnum(c)) {
            c = '_';
        }
    }

    return prefix + nameWithoutExt;
}

void ResourceManager::UnloadTexture(const std::string& key)
{
    auto it = textures.find(key);
    if (it != textures.end())
    {
        SDL_DestroyTexture(it->second);
        textures.erase(it);
#ifdef _DEBUG
        std::cout << "ж������: " << key << std::endl;
#endif
    }
}

Mix_Chunk* ResourceManager::LoadSound(const std::string& path, const std::string& key)
{
    std::string actualKey = key.empty() ? path : key;

    if (sounds.find(actualKey) != sounds.end())
    {
        return sounds[actualKey];
    }

    Mix_Chunk* sound = Mix_LoadWAV(path.c_str());
    if (!sound)
    {
        std::cerr << "������Чʧ��: " << path << " - " << Mix_GetError() << std::endl;
        return nullptr;
    }

    sounds[actualKey] = sound;
#ifdef _DEBUG
    std::cout << "�ɹ�������Ч: " << path << std::endl;
#endif
    return sound;
}

Mix_Chunk* ResourceManager::GetSound(const std::string& key)
{
    auto it = sounds.find(key);
    if (it != sounds.end())
    {
        return it->second;
    }
    std::cerr << "����: ��Чδ�ҵ�: " << key << std::endl;
    return nullptr;
}

void ResourceManager::UnloadSound(const std::string& key)
{
    auto it = sounds.find(key);
    if (it != sounds.end())
    {
        Mix_FreeChunk(it->second);
        sounds.erase(it);
#ifdef _DEBUG
        std::cout << "ж����Ч: " << key << std::endl;
#endif
    }
}

Mix_Music* ResourceManager::LoadMusic(const std::string& path, const std::string& key)
{
    std::string actualKey = key.empty() ? path : key;

    if (music.find(actualKey) != music.end())
    {
        return music[actualKey];
    }

    Mix_Music* music = Mix_LoadMUS(path.c_str());
    if (!music)
    {
        std::cerr << "��������ʧ��: " << path << " - " << Mix_GetError() << std::endl;
        return nullptr;
    }

    this->music[actualKey] = music;
#ifdef _DEBUG
    std::cout << "�ɹ���������: " << path << std::endl;
#endif
    return music;
}

Mix_Music* ResourceManager::GetMusic(const std::string& key)
{
    auto it = music.find(key);
    if (it != music.end())
    {
        return it->second;
    }
    std::cerr << "����: ����δ�ҵ�: " << key << std::endl;
    return nullptr;
}

void ResourceManager::UnloadMusic(const std::string& key)
{
    auto it = music.find(key);
    if (it != music.end())
    {
        Mix_FreeMusic(it->second);
        music.erase(it);
#ifdef _DEBUG
        std::cout << "ж������: " << key << std::endl;
#endif
    }
}

void ResourceManager::LoadTexturePack(const std::vector<std::pair<std::string, std::string>>& texturePaths)
{
    for (const auto& pair : texturePaths)
    {
        LoadTexture(pair.first, pair.second);
    }
}

SDL_Texture* ResourceManager::CreateTextureFromSurface(SDL_Surface* surface) {
    if (!surface || !renderer) return nullptr;
    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
    if (texture) {
        SDL_SetTextureScaleMode(texture, SDL_ScaleModeLinear);
        SDL_SetTextureBlendMode(texture, SDL_BLENDMODE_BLEND);
    }
    return texture;
}

// ���طָ���ͼ
bool ResourceManager::LoadTiledTexture(const TiledImageInfo& info, const std::string& prefix) {
    // �������Ҫ�ָֱ�ӵ��� LoadTexture
    if (info.columns <= 1 && info.rows <= 1) {
        std::string key = GenerateStandardKey(info.path, prefix);
        return LoadTexture(info.path, key) != nullptr;
    }

    // ����ԭͼ��Surface
    SDL_Surface* originalSurface = IMG_Load(info.path.c_str());
    if (!originalSurface) {
        std::cerr << "�޷�����ͼƬ: " << info.path << " - " << IMG_GetError() << std::endl;
        return false;
    }

    int imgW = originalSurface->w;
    int imgH = originalSurface->h;
    int tileW = imgW / info.columns;
    int tileH = imgH / info.rows;

    // ����Ƿ�����
    if (imgW % info.columns != 0 || imgH % info.rows != 0) {
        std::cerr << "����: ͼƬ�ߴ� " << imgW << "x" << imgH
            << " ���ܱ� " << info.columns << "x" << info.rows
            << " ���������ܲ�����Ե�ü�" << std::endl;
    }

    std::string baseKey = GenerateStandardKey(info.path, prefix);
    bool success = true;

    // ����ÿ����ͼ
    for (int row = 0; row < info.rows; ++row) {
        for (int col = 0; col < info.columns; ++col) {
            // ������Surface
            SDL_Surface* tileSurface = SDL_CreateRGBSurface(
                0, tileW, tileH,
                originalSurface->format->BitsPerPixel,
                originalSurface->format->Rmask,
                originalSurface->format->Gmask,
                originalSurface->format->Bmask,
                originalSurface->format->Amask
            );
            if (!tileSurface) {
                std::cerr << "�޷�������Surface: " << SDL_GetError() << std::endl;
                success = false;
                continue;
            }

            // ����Դ����
            SDL_Rect srcRect = { col * tileW, row * tileH, tileW, tileH };
            // ��ԭͼָ�������Ƶ���Surface
            if (SDL_BlitSurface(originalSurface, &srcRect, tileSurface, nullptr) != 0) {
                std::cerr << "Blitʧ��: " << SDL_GetError() << std::endl;
                SDL_FreeSurface(tileSurface);
                success = false;
                continue;
            }

            // ��������
            SDL_Texture* texture = CreateTextureFromSurface(tileSurface);
            SDL_FreeSurface(tileSurface);

            if (!texture) {
                std::cerr << "�޷�����Surface��������" << std::endl;
                success = false;
                continue;
            }

            // ���ɴ�������key
            int index = row * info.columns + col;
            std::string key = baseKey + "_PART_" + std::to_string(index);
            textures[key] = texture;
#ifdef _DEBUG
            std::cout << "����������: " << key << " �ߴ� " << tileW << "x" << tileH << std::endl;
#endif
        }
    }

    SDL_FreeSurface(originalSurface);
    return success;
}

void ResourceManager::UnloadAll()
{
    // ж����������
    for (auto& pair : textures)
    {
        SDL_DestroyTexture(pair.second);
    }
    textures.clear();

    // ж����������
    for (auto& fontPair : fonts)
    {
        for (auto& sizePair : fontPair.second)
        {
            TTF_CloseFont(sizePair.second);
        }
    }
    fonts.clear();

    // ж��������Ч
    for (auto& pair : sounds)
    {
        Mix_FreeChunk(pair.second);
    }
    sounds.clear();

    // ж����������
    for (auto& pair : music)
    {
        Mix_FreeMusic(pair.second);
    }
    music.clear();

    // ж�����ж���
    mReanimations.clear();
#ifdef _DEBUG
    std::cout << "��ж��������Դ" << std::endl;
#endif
}



bool ResourceManager::HasTexture(const std::string& key) const
{
    return textures.find(key) != textures.end();
}

bool ResourceManager::HasFont(const std::string& key) const
{
    return fonts.find(key) != fonts.end();
}

bool ResourceManager::HasSound(const std::string& key) const
{
    return sounds.find(key) != sounds.end();
}

bool ResourceManager::HasMusic(const std::string& key) const
{
    return music.find(key) != music.end();
}