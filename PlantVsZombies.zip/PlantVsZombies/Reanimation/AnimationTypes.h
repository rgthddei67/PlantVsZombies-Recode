#pragma once
#ifndef _ANIMATIONTYPES_H
#define _ANIMATIONTYPES_H

// TODO: ����ֲ���ʬҲҪ������
enum class AnimationType
{
    ANIM_NONE,
    ANIM_SUN,
    ANIM_SUNFLOWER,
    ANIM_PEASHOOTER,
    ANIM_CHERRYBOMB,
    ANIM_NORMAL_ZOMBIE,
};

#endif