#pragma once
#ifndef _REANIMATION_H
#define _REANIMATION_H

#include "ReanimTypes.h"
#include <memory>
#include <vector>
#include <set>

constexpr float REANIM_MISSING_FIELD_FLOAT = -1024;
constexpr int REANIM_MISSING_FIELD_INT = -1024;

class Reanimation {
public:
    float mFPS = 12.0f;
    std::shared_ptr<std::vector<TrackInfo>> mTracks = nullptr;
    bool mIsLoaded = false;
    class ResourceManager* mResourceManager = nullptr;

public:
    Reanimation();
    ~Reanimation();

    // ����reanim�ļ�
    bool LoadFromFile(const std::string& filePath);

    // ��ȡ�����Ϣ
    size_t GetTrackCount() const;
    TrackInfo* GetTrack(int index);
    TrackInfo* GetTrack(const std::string& trackName);

    // ��ȡ��֡��
    int GetTotalFrames() const;
};

void GetDeltaTransform(const TrackFrameTransform& tSrc, const TrackFrameTransform& tDst,
    float tDelta, TrackFrameTransform& tOutput, bool useDestFrame = false);

#endif