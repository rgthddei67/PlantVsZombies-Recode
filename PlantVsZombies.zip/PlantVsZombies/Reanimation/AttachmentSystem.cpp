#include "AttachmentSystem.h"
#include "Animator.h"
#include <algorithm>
#include <iostream>

// ��SDL��ɫת��Ϊglm::vec4
static glm::vec4 ColorToVec4(const SDL_Color& color) {
    return glm::vec4(
        color.r / 255.0f,
        color.g / 255.0f,
        color.b / 255.0f,
        color.a / 255.0f
    );
}

// ��glm::vec4ת��ΪSDL��ɫ
static SDL_Color Vec4ToColor(const glm::vec4& vec) {
    return SDL_Color{
        static_cast<Uint8>(std::clamp(vec.r * 255.0f, 0.0f, 255.0f)),
        static_cast<Uint8>(std::clamp(vec.g * 255.0f, 0.0f, 255.0f)),
        static_cast<Uint8>(std::clamp(vec.b * 255.0f, 0.0f, 255.0f)),
        static_cast<Uint8>(std::clamp(vec.a * 255.0f, 0.0f, 255.0f))
    };
}

Attachment::Attachment(const std::string& name)
    : mName(name.empty() ? "Attachment_" + std::to_string(reinterpret_cast<uintptr_t>(this)) : name) {
    mEffects.reserve(MAX_EFFECTS_PER_ATTACHMENT);
}

Attachment::~Attachment() {
    // ��������Ч��
    Detach();
}

void Attachment::Update(float deltaTime) {
    if (!mAlive || !mVisible) return;

    // ����������Ч��
    CleanupDeadEffects();

    // ��������Ч��
    for (auto& effectInfo : mEffects) {
        if (effectInfo.IsValid()) {
            effectInfo.effect->Update(deltaTime);
        }
    }
}

void Attachment::Draw(SDL_Renderer* renderer, const TransformData& parentTransform) {
    if (!mAlive || !mVisible || !renderer) return;

    // �������ձ任
    TransformData finalTransform = parentTransform.Combine(mTransform);

    // ��������Ч��
    for (auto& effectInfo : mEffects) {
        if (!effectInfo.IsValid() || effectInfo.effect->IsAttached() != mAttached) {
            continue;
        }

        // ������ڵ������������˲����ƣ�������
        if (!mVisible && effectInfo.dontDrawIfParentHidden) {
            continue;
        }

        // ����Ч�������ձ任
        TransformData effectTransform = effectInfo.GetFinalTransform(finalTransform);

        // ����AnimatorЧ������ȡ�䵱ǰ��Alphaֵ��Ӧ��
        if (effectInfo.effect->GetEffectType() == EffectType::EFFECT_ANIMATION) {
            if (auto animator = std::dynamic_pointer_cast<Animator>(effectInfo.effect)) {
                // ��ȡAnimator�ĵ�ǰAlphaֵ
                float animatorAlpha = animator->GetAlpha();

                // ����Animator��ԭʼAlpha
                float originalAlpha = animatorAlpha;

                // ��Attachment��mAlphaӦ�õ�Animator����Ϊ������
                float combinedAlpha = originalAlpha * mAlpha;
                animator->SetAlpha(combinedAlpha);

                // ����Ч��
                effectInfo.effect->Draw(renderer, effectTransform);

                // �ָ�Animator��ԭʼAlpha�����ı�Animator�ڲ�״̬��
                animator->SetAlpha(originalAlpha);

                continue; // �Ѵ�����������һ��Ч��
            }
        }

        // ���ڷ�AnimatorЧ������������
        effectInfo.effect->Draw(renderer, effectTransform);
    }
}

void Attachment::SetPosition(const Vector& position) {
    mTransform.SetPosition(position);
}

void Attachment::SetPosition(float x, float y) {
    mTransform.SetPosition(x, y);
}

void Attachment::SetScale(const Vector& scale) {
    mTransform.SetScale(scale);
}

void Attachment::SetScale(float scale) {
    mTransform.SetScale(scale);
}

void Attachment::SetScale(float sx, float sy) {
    mTransform.SetScale(sx, sy);
}

void Attachment::SetRotation(float rotation) {
    mTransform.SetRotation(rotation);
}

void Attachment::OverrideColor(const SDL_Color& color) {
    mColorOverride = color;
    mHasColorOverride = true;

    // ������ɫ������Ч�������������˲�������
    for (auto& effectInfo : mEffects) {
        if (effectInfo.IsValid() && !effectInfo.dontPropagateColor) {
            effectInfo.effect->OverrideColor(color);
        }
    }
}

void Attachment::SetAlpha(float alpha) {
    mAlpha = std::clamp(alpha, 0.0f, 1.0f);

    // ����͸���ȵ�����Ч��
    for (auto& effectInfo : mEffects) {
        if (effectInfo.IsValid()) {
            effectInfo.effect->SetAlpha(mAlpha);
        }
    }
}

void Attachment::SetVisible(bool visible) {
    mVisible = visible;

    // �����ɼ��Ե�����Ч�������������˲��̳пɼ��ԣ�
    for (auto& effectInfo : mEffects) {
        if (effectInfo.IsValid() && effectInfo.inheritVisibility) {
            effectInfo.effect->SetVisible(visible);
        }
    }
}

void Attachment::PropagateColor(const SDL_Color& color,
    bool enableAdditive, const SDL_Color& additiveColor,
    bool enableOverlay, const SDL_Color& overlayColor) {
    mColorOverride = color;
    mHasColorOverride = true;

    // ������ɫ������Ч�������������˲�������
    for (auto& effectInfo : mEffects) {
        if (effectInfo.IsValid() && !effectInfo.dontPropagateColor) {
            effectInfo.effect->PropagateColor(color, enableAdditive, additiveColor,
                enableOverlay, overlayColor);
        }
    }
}

void Attachment::SetTransformMatrix(const glm::mat3& matrix) {
    mTransform.matrix = matrix;

    // �Ӿ�������ȡλ�á����ź���ת
    mTransform.position = glm::vec2(matrix[2][0], matrix[2][1]);
    mTransform.scale.x = glm::length(glm::vec2(matrix[0][0], matrix[0][1]));
    mTransform.scale.y = glm::length(glm::vec2(matrix[1][0], matrix[1][1]));

    if (mTransform.scale.x > 0 && mTransform.scale.y > 0) {
        mTransform.rotation = atan2(matrix[0][1] / mTransform.scale.y,
            matrix[0][0] / mTransform.scale.x);
    }
}

void Attachment::Die() {
    // ���Ϊ����
    mAlive = false;

    // ��������Ч��
    for (auto& effectInfo : mEffects) {
        if (effectInfo.IsValid()) {
            effectInfo.effect->Die();
        }
    }

    // ���Ч���б�
    mEffects.clear();
}

void Attachment::Detach() {
    // ��������Ч��
    for (auto& effectInfo : mEffects) {
        if (effectInfo.IsValid()) {
            effectInfo.effect->Detach();
        }
    }

    // ���Ч���б�
    mEffects.clear();

    // ���Ϊδ����
    mAttached = false;
}

bool Attachment::AddEffect(std::shared_ptr<IAttachmentEffect> effect,
    const Vector& offset,
    const Vector& scale,
    float rotation) {
    if (!effect || IsFull()) {
        return false;
    }

    // ���Ч���Ƿ��Ѿ�����
    if (effect->IsAttached()) {
        std::cerr << "Warning: Effect is already attached to another attachment!" << std::endl;
        return false;
    }

    // ����ƫ�Ʊ任
    TransformData offsetTransform;
    offsetTransform.SetPosition(offset);
    offsetTransform.SetScale(scale);
    offsetTransform.SetRotation(rotation);

    // ����Ч��Ϊ����״̬
    effect->SetAttached(true);

    // ����Ч����Ϣ
    AttachmentEffect effectInfo;
    effectInfo.effect = std::move(effect);
    effectInfo.offsetTransform = offsetTransform;

    // ���ӵ��б�
    mEffects.push_back(std::move(effectInfo));
    return true;
}

bool Attachment::AddEffect(std::shared_ptr<IAttachmentEffect> effect,
    float offsetX, float offsetY,
    float scaleX, float scaleY,
    float rotation) {
    return AddEffect(effect,
        Vector(offsetX, offsetY),
        Vector(scaleX, scaleY),
        rotation);
}

bool Attachment::AddAnimator(std::shared_ptr<Animator> animator,
    const Vector& offset,
    const Vector& scale,
    float rotation) {
    if (!animator) {
        return false;
    }

    // AnimatorӦ���Ѿ�ʵ����IAttachmentEffect�ӿ�
    return AddEffect(std::static_pointer_cast<IAttachmentEffect>(animator),
        offset, scale, rotation);
}

bool Attachment::AddAnimator(std::shared_ptr<Animator> animator,
    float offsetX, float offsetY,
    float scaleX, float scaleY,
    float rotation) {
    return AddAnimator(animator,
        Vector(offsetX, offsetY),
        Vector(scaleX, scaleY),
        rotation);
}

bool Attachment::RemoveEffect(int index) {
    if (index < 0 || index >= static_cast<int>(mEffects.size())) {
        return false;
    }

    auto& effectInfo = mEffects[index];
    if (effectInfo.IsValid()) {
        effectInfo.effect->SetAttached(false);
        effectInfo.effect->Detach();
    }

    mEffects.erase(mEffects.begin() + index);
    return true;
}

bool Attachment::RemoveEffect(std::shared_ptr<IAttachmentEffect> effect) {
    for (auto it = mEffects.begin(); it != mEffects.end(); ++it) {
        if (it->effect == effect) {
            if (it->IsValid()) {
                it->effect->SetAttached(false);
                it->effect->Detach();
            }
            mEffects.erase(it);
            return true;
        }
    }
    return false;
}

void Attachment::RemoveAllEffects() {
    for (auto& effectInfo : mEffects) {
        if (effectInfo.IsValid()) {
            effectInfo.effect->SetAttached(false);
            effectInfo.effect->Detach();
        }
    }
    mEffects.clear();
}

std::shared_ptr<IAttachmentEffect> Attachment::FindEffect(int index) const {
    if (index >= 0 && index < static_cast<int>(mEffects.size())) {
        return mEffects[index].effect;
    }
    return nullptr;
}

std::shared_ptr<Animator> Attachment::FindFirstAnimator() const {
    for (const auto& effectInfo : mEffects) {
        if (effectInfo.effect && effectInfo.effect->GetEffectType() == EffectType::EFFECT_ANIMATION) {
            return std::dynamic_pointer_cast<Animator>(effectInfo.effect);
        }
    }
    return nullptr;
}

std::vector<std::shared_ptr<Animator>> Attachment::FindAllAnimators() const {
    std::vector<std::shared_ptr<Animator>> animators;
    for (const auto& effectInfo : mEffects) {
        if (effectInfo.effect && effectInfo.effect->GetEffectType() == EffectType::EFFECT_ANIMATION) {
            if (auto animator = std::dynamic_pointer_cast<Animator>(effectInfo.effect)) {
                animators.push_back(animator);
            }
        }
    }
    return animators;
}

void Attachment::CleanupDeadEffects() {
    // �Ƴ���������Ч��Ч��
    auto newEnd = std::remove_if(mEffects.begin(), mEffects.end(),
        [](const AttachmentEffect& effectInfo) {
            return !effectInfo.IsValid();
        });

    if (newEnd != mEffects.end()) {
        mEffects.erase(newEnd, mEffects.end());
    }
}

AttachmentSystem::~AttachmentSystem() {
    RemoveAllAttachments();
}

std::shared_ptr<Attachment> AttachmentSystem::CreateAttachment(const std::string& name) {
    // ��������Ƿ��Ѵ���
    if (!name.empty() && HasAttachment(name)) {
        std::cerr << "AttachmentSystem: Attachment with name '" << name << "' already exists!" << std::endl;
        return nullptr;
    }

    auto attachment = std::make_shared<Attachment>(name);
    mActiveAttachments.push_back(attachment);

    if (!name.empty()) {
        mNamedAttachments[name] = attachment;
    }

    return attachment;
}

std::shared_ptr<Attachment> AttachmentSystem::GetAttachment(const std::string& name) {
    auto it = mNamedAttachments.find(name);
    if (it != mNamedAttachments.end()) {
        return it->second;
    }
    return nullptr;
}

bool AttachmentSystem::HasAttachment(const std::string& name) const {
    return mNamedAttachments.find(name) != mNamedAttachments.end();
}

bool AttachmentSystem::RemoveAttachment(const std::string& name) {
    auto it = mNamedAttachments.find(name);
    if (it == mNamedAttachments.end()) {
        return false;
    }

    auto attachment = it->second;

    // �ӻ�б����Ƴ�
    mActiveAttachments.erase(
        std::remove(mActiveAttachments.begin(), mActiveAttachments.end(), attachment),
        mActiveAttachments.end()
    );

    // ���ٸ���
    attachment->Die();

    // ������ӳ�����Ƴ�
    mNamedAttachments.erase(it);

    return true;
}

void AttachmentSystem::RemoveAllAttachments() {
    for (auto& attachment : mActiveAttachments) {
        if (attachment) {
            attachment->Die();
        }
    }

    mActiveAttachments.clear();
    mNamedAttachments.clear();
}

void AttachmentSystem::UpdateAll(float deltaTime) {
    // ������������
    CleanupDeadAttachments();

    // �������и���
    for (auto& attachment : mActiveAttachments) {
        UpdateAttachment(attachment, deltaTime);
    }
}

void AttachmentSystem::DrawAll(SDL_Renderer* renderer) {
    if (!renderer) return;

    TransformData identity; // ��λ�任

    for (auto& attachment : mActiveAttachments) {
        if (attachment && attachment->IsAlive()) {
            attachment->Draw(renderer, identity);
        }
    }
}

void AttachmentSystem::CleanupDeadAttachments() {
    // �ӻ�б����Ƴ���������
    auto newEnd = std::remove_if(mActiveAttachments.begin(), mActiveAttachments.end(),
        [](const std::shared_ptr<Attachment>& attachment) {
            return !attachment || !attachment->IsAlive();
        });

    // ������ӳ�����Ƴ���������
    for (auto it = newEnd; it != mActiveAttachments.end(); ++it) {
        for (auto mapIt = mNamedAttachments.begin(); mapIt != mNamedAttachments.end(); ) {
            if (mapIt->second == *it) {
                mapIt = mNamedAttachments.erase(mapIt);
            }
            else {
                ++mapIt;
            }
        }
    }

    if (newEnd != mActiveAttachments.end()) {
        mActiveAttachments.erase(newEnd, mActiveAttachments.end());
    }
}

std::vector<std::string> AttachmentSystem::GetAllAttachmentNames() const {
    std::vector<std::string> names;
    names.reserve(mNamedAttachments.size());

    for (const auto& pair : mNamedAttachments) {
        names.push_back(pair.first);
    }

    return names;
}

void AttachmentSystem::UpdateAttachment(std::shared_ptr<Attachment>& attachment, float deltaTime) {
    if (attachment && attachment->IsAlive()) {
        attachment->Update(deltaTime);
    }
}