#pragma once
#ifndef _H_MESSAGEBOX_H
#define _H_MESSAGEBOX_H

#include "../Game/GameObject.h"
#include "Button.h"
#include <SDL2/SDL.h>
#include <string>
#include <functional>
#include <memory>
#include <vector>

class GameMessageBox : public GameObject {
public:
    // ��ť���ýṹ
    struct ButtonConfig {
        std::string text;                 // ��ť����
        Vector pos;
        std::function<void()> callback;   // ����ص�
        bool autoClose = true;             // ������Ƿ��Զ��ر���Ϣ��
    };

    GameMessageBox(const Vector& pos,
        const std::string& message,
        const std::vector<ButtonConfig>& buttons,
        const std::string& title = "",
        const std::string& backgroundImageKey = "",
        float scale = 1.0f);

    ~GameMessageBox();

    virtual void Start() override;
    virtual void Draw(SDL_Renderer* renderer) override;

    // �ر���Ϣ�򣨴�GameObjectManager�������Լ���
    void Close();

private:
    Vector m_position;
    float m_scale;
    Vector m_size;               // ʵ�ʴ�С���ѳ����ţ�
    std::string m_title;
    std::string m_message;
    std::string m_backgroundImageKey = ResourceKeys::Textures::IMAGE_MESSAGEBOX;
    std::vector<ButtonConfig> m_buttonConfigs;
    std::vector<std::shared_ptr<Button>> m_buttons;

    SDL_Color m_textColor = { 245, 214, 127, 255 };
    SDL_Color m_titleColor = { 53, 191, 61, 255 };

    // ��ȡ����ͼƬԭʼ�ߴ磨����ͼƬ�򷵻�Ĭ�ϳߴ磩
    Vector GetBackgroundOriginalSize() const;
};

#endif